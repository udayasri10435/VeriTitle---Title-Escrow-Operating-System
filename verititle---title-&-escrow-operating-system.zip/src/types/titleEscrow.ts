export type TransactionType = 'Residential Purchase' | 'Residential Refinance' | 'Commercial Purchase' | 'Cash Purchase';

export type OrderStatus = 
  | 'Intake / Open'
  | 'Title Search & Abstract'
  | 'Exam & Commitment Issued'
  | 'Clear to Close'
  | 'Closing Scheduled'
  | 'Closed & Executed'
  | 'Disbursed & Recorded'
  | 'Policy Issued';

export type Underwriter = 
  | 'First American Title Insurance Co.'
  | 'Fidelity National Title'
  | 'Old Republic National Title'
  | 'Stewart Title Guaranty'
  | 'Chicago Title Insurance Co.';

export interface Party {
  id: string;
  role: 'Buyer' | 'Seller' | 'Borrower' | 'Lender' | 'Listing Agent' | 'Buyer Agent' | 'Settlement Officer' | 'Underwriter';
  name: string;
  company?: string;
  email: string;
  phone: string;
  address?: string;
}

export interface PropertyDetails {
  address: string;
  city: string;
  state: string;
  zip: string;
  county: string;
  parcelId: string; // APN
  legalDescription: string;
  propertyType: 'Single Family Residence' | 'Condominium' | 'Commercial' | 'Multi-Family';
}

export interface TitleRequirement {
  id: string;
  code: string;
  description: string;
  status: 'Pending' | 'Satisfied' | 'Waived';
  category: 'Lien / Mortgage' | 'Taxes' | 'Legal / Authority' | 'Affidavit' | 'Survey';
  satisfiedAt?: string;
  notes?: string;
}

export interface TitleException {
  id: string;
  itemNumber: number;
  description: string;
  type: 'Standard' | 'Specific' | 'Easement' | 'Restriction';
}

export interface SettlementLineItem {
  id: string;
  section: '100_Financial' | '200_Prorations' | '500_TitleCharges' | '600_GovernmentCharges' | '700_Payoffs' | '800_Miscellaneous';
  lineCode: string;
  description: string;
  payeeOrPayor: string;
  borrowerDebit?: number;
  borrowerCredit?: number;
  sellerDebit?: number;
  sellerCredit?: number;
}

export interface AltaStatement {
  fileNumber: string;
  settlementDate: string;
  disbursementDate: string;
  lineItems: SettlementLineItem[];
  earnestMoney: number;
  loanAmount: number;
  purchasePrice: number;
  // Totals
  borrowerTotalDebits: number;
  borrowerTotalCredits: number;
  borrowerDueFromOrTo: number; // Positive = Due from borrower, Negative = Refund to borrower
  sellerTotalDebits: number;
  sellerTotalCredits: number;
  sellerDueToOrFrom: number; // Positive = Due to seller, Negative = Due from seller
}

export interface EscrowDeposit {
  id: string;
  date: string;
  source: string;
  referenceNumber: string;
  type: 'Wire Transfer' | 'Cashier Check' | 'ACH / Direct Deposit';
  amount: number;
  status: 'Pending' | 'Cleared' | 'On Hold';
  verifiedBy?: string;
}

export interface DisbursementItem {
  id: string;
  category: 'Mortgage Payoff' | 'Broker Commission' | 'Taxes' | 'Recording Fee' | 'Title Premium' | 'Escrow Settlement Fee' | 'Seller Net Proceeds' | 'HOA Transfer';
  payee: string;
  accountNumberMasked: string;
  routingNumberMasked: string;
  amount: number;
  method: 'Wire Transfer' | 'Trust Account Check' | 'Electronic Recording ACH';
  status: 'Draft' | 'Approved' | 'Queued' | 'Disbursed' | 'Void';
  wireFraudVerified: boolean;
  wireFraudVerifiedBy?: string;
  wireFraudVerificationTime?: string;
  checkNumber?: string;
}

export interface ClosingDocument {
  id: string;
  title: string;
  category: 'Settlement Statement' | 'Deed' | 'Commitment' | 'Affidavit' | 'Lender Package' | 'Wire Notice';
  totalPages: number;
  status: 'Draft' | 'Ready for Review' | 'Out for Signature' | 'Signed & Notarized';
  requiredSigners: ('Buyer' | 'Seller' | 'Notary' | 'Settlement Agent')[];
  signaturesCollected: ('Buyer' | 'Seller' | 'Notary' | 'Settlement Agent')[];
  lastModified: string;
}

export interface ClosingSession {
  id: string;
  fileNumber: string;
  modality: 'In-Person Settlement' | 'Remote Online Notarization (RON)' | 'Mobile Notary';
  scheduledDate: string;
  scheduledTime: string;
  locationOrPlatform: string;
  notaryName: string;
  notaryCommissionNumber: string;
  status: 'Scheduled' | 'In Progress' | 'Completed' | 'Rescheduled';
  notes?: string;
}

export interface Order {
  id: string;
  fileNumber: string;
  orderDate: string;
  targetClosingDate: string;
  disbursementDate: string;
  type: TransactionType;
  status: OrderStatus;
  underwriter: Underwriter;
  policyNumber?: string;
  property: PropertyDetails;
  parties: Party[];
  purchasePrice: number;
  loanAmount: number;
  earnestMoney: number;
  titleRequirements: TitleRequirement[];
  titleExceptions: TitleException[];
  altaStatement: AltaStatement;
  escrowDeposits: EscrowDeposit[];
  disbursements: DisbursementItem[];
  documents: ClosingDocument[];
  closingSession: ClosingSession;
  escrowBalanced: boolean;
  disbursementAuthorized: boolean;
  disbursementAuthorizedBy?: string;
  internalNotes: string[];
}
