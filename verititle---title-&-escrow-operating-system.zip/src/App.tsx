import React, { useState, useEffect } from 'react';
import { initialOrders } from './data/seedData';
import { Order } from './types/titleEscrow';
import { Header } from './components/layout/Header';
import { NavigationTabs } from './components/layout/NavigationTabs';
import { OrderList } from './components/orders/OrderList';
import { OrderDetail } from './components/orders/OrderDetail';
import { NewOrderModal } from './components/orders/NewOrderModal';
import { DocumentPrepView } from './components/documents/DocumentPrepView';
import { ClosingRoomView } from './components/closing/ClosingRoomView';
import { DisbursementLedgerView } from './components/disbursement/DisbursementLedgerView';
import { TitleCalculatorModal } from './components/tools/TitleCalculatorModal';
import { AltaComplianceView } from './components/tools/AltaComplianceView';
import { RotateCcw, Building2 } from 'lucide-react';

const STORAGE_KEY = 'verititle_orders_v1';

export default function App() {
  const [orders, setOrders] = useState<Order[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch {
      // Fallback
    }
    return initialOrders;
  });

  const [activeOrderId, setActiveOrderId] = useState<string>(() => {
    return orders[0]?.id || 'order-1';
  });

  const [activeTab, setActiveTab] = useState<string>('pipeline');
  const [isNewOrderModalOpen, setIsNewOrderModalOpen] = useState(false);
  const [isCalculatorModalOpen, setIsCalculatorModalOpen] = useState(false);

  // Sync to local storage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(orders));
    } catch (e) {
      console.warn('Storage sync error', e);
    }
  }, [orders]);

  const activeOrder = orders.find((o) => o.id === activeOrderId) || orders[0] || null;

  // Update order handler
  const handleUpdateOrder = (updatedOrder: Order) => {
    setOrders((prev) =>
      prev.map((o) => (o.id === updatedOrder.id ? updatedOrder : o))
    );
  };

  // Add order handler
  const handleSaveNewOrder = (newOrder: Order) => {
    setOrders((prev) => [newOrder, ...prev]);
    setActiveOrderId(newOrder.id);
    setActiveTab('order-detail');
  };

  // Select order and optionally navigate to tab
  const handleSelectOrder = (order: Order, targetTab?: string) => {
    setActiveOrderId(order.id);
    if (targetTab) {
      setActiveTab(targetTab);
    }
  };

  // Reset to sample initial data
  const handleResetData = () => {
    if (window.confirm('Reset all title orders and escrow ledgers to initial seed data?')) {
      setOrders(initialOrders);
      setActiveOrderId(initialOrders[0].id);
      setActiveTab('pipeline');
      localStorage.removeItem(STORAGE_KEY);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col">
      {/* Top Header */}
      <Header
        orders={orders}
        activeOrder={activeOrder}
        onSelectOrder={(ord) => handleSelectOrder(ord)}
        onOpenNewOrder={() => setIsNewOrderModalOpen(true)}
        onOpenCalculator={() => setIsCalculatorModalOpen(true)}
        onOpenCompliance={() => setActiveTab('compliance')}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
      />

      {/* Main Navigation Tabs */}
      <NavigationTabs
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        activeOrder={activeOrder}
      />

      {/* Viewport Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* TAB 1: Order Pipeline & Intake */}
        {activeTab === 'pipeline' && (
          <OrderList
            orders={orders}
            onSelectOrder={handleSelectOrder}
            onOpenNewOrder={() => setIsNewOrderModalOpen(true)}
          />
        )}

        {/* TAB 2: Selected Order File Workspace */}
        {activeTab === 'order-detail' && activeOrder && (
          <OrderDetail
            order={activeOrder}
            onUpdateOrder={handleUpdateOrder}
            onNavigateTab={setActiveTab}
          />
        )}

        {/* TAB 3: Doc Prep & ALTA Settlement Statement */}
        {activeTab === 'doc-prep' && activeOrder && (
          <DocumentPrepView
            order={activeOrder}
            onUpdateOrder={handleUpdateOrder}
            onNavigateTab={setActiveTab}
          />
        )}

        {/* TAB 4: Closing Room & Signatures */}
        {activeTab === 'closing' && activeOrder && (
          <ClosingRoomView
            order={activeOrder}
            onUpdateOrder={handleUpdateOrder}
            onNavigateTab={setActiveTab}
          />
        )}

        {/* TAB 5: Escrow Accounting & Funding Disbursement */}
        {activeTab === 'disbursement' && activeOrder && (
          <DisbursementLedgerView
            order={activeOrder}
            onUpdateOrder={handleUpdateOrder}
            onNavigateTab={setActiveTab}
          />
        )}

        {/* TAB 6: ALTA Best Practices Framework (7 Pillars) */}
        {activeTab === 'compliance' && <AltaComplianceView />}
      </main>

      {/* Modals */}
      <NewOrderModal
        isOpen={isNewOrderModalOpen}
        onClose={() => setIsNewOrderModalOpen(false)}
        onSaveOrder={handleSaveNewOrder}
        existingCount={orders.length}
      />

      <TitleCalculatorModal
        isOpen={isCalculatorModalOpen}
        onClose={() => setIsCalculatorModalOpen(false)}
        activeOrder={activeOrder}
        onUpdateOrder={handleUpdateOrder}
      />

      {/* Minimal Footer */}
      <footer className="bg-white border-t border-slate-200 py-4 no-print mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-2">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-700">VeriTitle OS</span>
            <span>·</span>
            <span>Title & Escrow Settlement Operating System</span>
            <span>·</span>
            <span>ALTA Best Practices Compliant</span>
          </div>
          <div className="flex items-center gap-4">
            <button
              onClick={handleResetData}
              className="inline-flex items-center gap-1 text-slate-500 hover:text-slate-800 transition-colors"
              title="Reset state to initial sample files"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset Sample Files</span>
            </button>
            <span>&copy; {new Date().getFullYear()} VeriTitle Settlement Technologies</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
