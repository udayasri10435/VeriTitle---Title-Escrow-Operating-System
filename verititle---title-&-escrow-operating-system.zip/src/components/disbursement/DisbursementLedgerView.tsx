import React, { useState, useMemo } from 'react';
import { 
  DollarSign, 
  CheckCircle2, 
  AlertTriangle, 
  ShieldCheck, 
  PhoneCall, 
  Send, 
  Plus, 
  Printer, 
  Download, 
  Lock, 
  Check, 
  FileCheck,
  ArrowDownLeft,
  ArrowUpRight,
  ShieldAlert,
  Building,
  CreditCard
} from 'lucide-react';
import { Order, DisbursementItem, EscrowDeposit } from '../../types/titleEscrow';
import { formatCurrency, formatDate } from '../../utils/formatters';

interface DisbursementLedgerViewProps {
  order: Order;
  onUpdateOrder: (updatedOrder: Order) => void;
  onNavigateTab: (tab: string) => void;
}

export const DisbursementLedgerView: React.FC<DisbursementLedgerViewProps> = ({
  order,
  onUpdateOrder,
  onNavigateTab,
}) => {
  // Verification modal state
  const [verifyingItem, setVerifyingItem] = useState<DisbursementItem | null>(null);
  const [callbackNumber, setCallbackNumber] = useState('(512) 555-0841');
  const [officerName, setOfficerName] = useState('Katherine Reed');
  const [callbackConfirmed, setCallbackConfirmed] = useState(false);

  // Add Deposit Modal
  const [showAddDepositModal, setShowAddDepositModal] = useState(false);
  const [depSource, setDepSource] = useState('');
  const [depAmount, setDepAmount] = useState('');
  const [depType, setDepType] = useState<EscrowDeposit['type']>('Wire Transfer');
  const [depRef, setDepRef] = useState('');

  // Add Disbursement Modal
  const [showAddDisbModal, setShowAddDisbModal] = useState(false);
  const [disbCategory, setDisbCategory] = useState<DisbursementItem['category']>('Seller Net Proceeds');
  const [disbPayee, setDisbPayee] = useState('');
  const [disbAmount, setDisbAmount] = useState('');
  const [disbMethod, setDisbMethod] = useState<DisbursementItem['method']>('Wire Transfer');
  const [disbAccount, setDisbAccount] = useState('******8834');
  const [disbRouting, setDisbRouting] = useState('111900659');

  // Math totals
  const totalInflows = useMemo(() => {
    return order.escrowDeposits.reduce((sum, d) => sum + d.amount, 0);
  }, [order.escrowDeposits]);

  const totalOutflows = useMemo(() => {
    return order.disbursements.reduce((sum, d) => sum + d.amount, 0);
  }, [order.disbursements]);

  const escrowBalance = Math.round((totalInflows - totalOutflows) * 100) / 100;
  const isBalanced = Math.abs(escrowBalance) < 0.01;

  // Verify Wire Modal Action
  const handleConfirmWireVerification = () => {
    if (!verifyingItem || !callbackConfirmed) return;

    const timeStr = `${new Date().toISOString().split('T')[0]} ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
    const updatedDisbursements = order.disbursements.map((item) => {
      if (item.id === verifyingItem.id) {
        return {
          ...item,
          wireFraudVerified: true,
          wireFraudVerifiedBy: `${officerName} (Phone Callback to ${callbackNumber})`,
          wireFraudVerificationTime: timeStr,
        };
      }
      return item;
    });

    onUpdateOrder({
      ...order,
      disbursements: updatedDisbursements,
      internalNotes: [
        `${new Date().toISOString().split('T')[0]}: Wire fraud verification completed for ${verifyingItem.payee} (${formatCurrency(verifyingItem.amount)}) via callback to ${callbackNumber}.`,
        ...order.internalNotes,
      ],
    });

    setVerifyingItem(null);
    setCallbackConfirmed(false);
  };

  // Add new Deposit
  const handleSaveDeposit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!depSource || !depAmount) return;

    const newDep: EscrowDeposit = {
      id: `dep-${Date.now()}`,
      date: new Date().toISOString().split('T')[0],
      source: depSource,
      amount: parseFloat(depAmount),
      type: depType,
      referenceNumber: depRef || `REF-${Math.floor(100000 + Math.random() * 900000)}`,
      status: 'Cleared',
      verifiedBy: 'Escrow Officer',
    };

    onUpdateOrder({
      ...order,
      escrowDeposits: [...order.escrowDeposits, newDep],
      internalNotes: [
        `${new Date().toISOString().split('T')[0]}: Recorded escrow deposit of ${formatCurrency(parseFloat(depAmount))} from ${depSource}.`,
        ...order.internalNotes,
      ],
    });

    setShowAddDepositModal(false);
    setDepSource('');
    setDepAmount('');
  };

  // Add new Disbursement
  const handleSaveDisbursement = (e: React.FormEvent) => {
    e.preventDefault();
    if (!disbPayee || !disbAmount) return;

    const newDisb: DisbursementItem = {
      id: `disb-${Date.now()}`,
      category: disbCategory,
      payee: disbPayee,
      amount: parseFloat(disbAmount),
      method: disbMethod,
      accountNumberMasked: disbAccount || '******1234',
      routingNumberMasked: disbRouting || '111000025',
      status: 'Approved',
      wireFraudVerified: disbMethod !== 'Wire Transfer',
      checkNumber: disbMethod === 'Trust Account Check' ? `CHK-${Math.floor(10000 + Math.random() * 90000)}` : undefined,
    };

    onUpdateOrder({
      ...order,
      disbursements: [...order.disbursements, newDisb],
      internalNotes: [
        `${new Date().toISOString().split('T')[0]}: Added disbursement of ${formatCurrency(parseFloat(disbAmount))} to ${disbPayee}.`,
        ...order.internalNotes,
      ],
    });

    setShowAddDisbModal(false);
    setDisbPayee('');
    setDisbAmount('');
  };

  // Release and Disburse all funds
  const handleReleaseDisbursements = () => {
    const allWiresVerified = order.disbursements
      .filter((d) => d.method === 'Wire Transfer')
      .every((d) => d.wireFraudVerified);

    if (!allWiresVerified) {
      alert('Security Alert: All outgoing wire transfers must have verbal callback fraud verification completed before release!');
      return;
    }

    if (!isBalanced) {
      alert(`Ledger Out of Balance: Escrow balance is ${formatCurrency(escrowBalance)}. File must balance to exactly $0.00 before releasing funds.`);
      return;
    }

    const updatedDisbursements = order.disbursements.map((d) => ({
      ...d,
      status: 'Disbursed' as const,
    }));

    onUpdateOrder({
      ...order,
      status: 'Disbursed & Recorded',
      disbursementAuthorized: true,
      disbursementAuthorizedBy: 'Katherine Reed, Chief Escrow Officer',
      disbursements: updatedDisbursements,
      internalNotes: [
        `${new Date().toISOString().split('T')[0]}: Funds released! All ${order.disbursements.length} disbursements transmitted. Escrow ledger fully balanced at $0.00.`,
        ...order.internalNotes,
      ],
    });
  };

  return (
    <div className="space-y-6">
      {/* Escrow Balancing Dashboard Card */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                Escrow Trust Accounting Ledger
              </span>
              <span className="text-xs text-slate-400">·</span>
              <span className="text-xs font-mono font-bold text-slate-900">File {order.fileNumber}</span>
            </div>
            <h2 className="text-xl font-bold text-slate-900 mt-1">
              Three-Way Balanced Settlement Funds
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Strict ALTA Pillar 2 compliant escrow accounting. File must achieve a net zero ($0.00) balance prior to disbursement authorization.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => window.print()}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-lg no-print"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Ledger</span>
            </button>

            {order.disbursementAuthorized ? (
              <div className="flex items-center gap-2 px-4 py-2 bg-emerald-50 text-emerald-800 border border-emerald-300 rounded-lg text-xs font-bold">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Disbursements Released & Funded</span>
              </div>
            ) : (
              <button
                onClick={handleReleaseDisbursements}
                disabled={!isBalanced || order.disbursements.length === 0}
                className={`inline-flex items-center gap-2 px-4 py-2.5 text-xs font-bold rounded-lg shadow-sm transition-all ${
                  isBalanced && order.disbursements.length > 0
                    ? 'bg-emerald-600 hover:bg-emerald-500 text-white cursor-pointer'
                    : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                }`}
              >
                <Send className="w-4 h-4" />
                <span>Authorize & Release Disbursements</span>
              </button>
            )}
          </div>
        </div>

        {/* Financial Balancing Meters */}
        <div className="mt-6 grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4 border-t border-slate-100">
          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
            <div className="flex items-center justify-between text-xs text-slate-500">
              <span className="font-medium flex items-center gap-1">
                <ArrowDownLeft className="w-3.5 h-3.5 text-emerald-600" />
                Total Escrow Inflows (Deposits)
              </span>
              <span className="font-mono text-slate-700">{order.escrowDeposits.length} deposits</span>
            </div>
            <div className="mt-2 text-2xl font-bold font-mono text-slate-900 tabular-nums">
              {formatCurrency(totalInflows)}
            </div>
            <span className="text-[11px] text-emerald-700 mt-1 block">Cleared Trust Funds</span>
          </div>

          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
            <div className="flex items-center justify-between text-xs text-slate-500">
              <span className="font-medium flex items-center gap-1">
                <ArrowUpRight className="w-3.5 h-3.5 text-blue-600" />
                Total Outflows (Disbursements)
              </span>
              <span className="font-mono text-slate-700">{order.disbursements.length} payees</span>
            </div>
            <div className="mt-2 text-2xl font-bold font-mono text-slate-900 tabular-nums">
              {formatCurrency(totalOutflows)}
            </div>
            <span className="text-[11px] text-slate-500 mt-1 block">Wires, Checks & Recording Fees</span>
          </div>

          <div className={`p-4 rounded-xl border ${
            isBalanced ? 'bg-emerald-50/70 border-emerald-300' : 'bg-amber-50 border-amber-300'
          }`}>
            <div className="flex items-center justify-between text-xs">
              <span className="font-medium text-slate-700">Cash to Balance</span>
              <span className={`font-mono text-[10px] font-bold px-2 py-0.5 rounded ${
                isBalanced ? 'bg-emerald-200 text-emerald-900' : 'bg-amber-200 text-amber-900'
              }`}>
                {isBalanced ? 'NET ZERO BALANCED' : 'OUT OF BALANCE'}
              </span>
            </div>
            <div className={`mt-2 text-2xl font-bold font-mono tabular-nums ${
              isBalanced ? 'text-emerald-700' : 'text-amber-700'
            }`}>
              {formatCurrency(escrowBalance)}
            </div>
            <span className="text-[11px] text-slate-600 mt-1 block">
              {isBalanced ? 'Ready for release sign-off' : 'Adjust deposits or payouts to zero out'}
            </span>
          </div>
        </div>
      </div>

      {/* TWO COLUMN WORKSPACE: Inflows vs Outflows */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* LEFT COLUMN: Escrow Deposits (Inflows) */}
        <div className="lg:col-span-5 bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                <ArrowDownLeft className="w-4 h-4 text-emerald-600" />
                Incoming Escrow Deposits
              </h3>
              <p className="text-[11px] text-slate-500">Earnest money, lender funding wire, buyer cash-to-close.</p>
            </div>
            <button
              onClick={() => setShowAddDepositModal(true)}
              className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg no-print"
            >
              <Plus className="w-3 h-3" />
              <span>Record Wire</span>
            </button>
          </div>

          <div className="space-y-3">
            {order.escrowDeposits.map((dep) => (
              <div key={dep.id} className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs space-y-1">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-slate-900">{dep.source}</span>
                  <span className="font-mono font-bold text-slate-900 text-sm tabular-nums">
                    {formatCurrency(dep.amount)}
                  </span>
                </div>
                <div className="flex items-center justify-between text-[11px] text-slate-500">
                  <span className="font-mono">{dep.referenceNumber}</span>
                  <span className="text-emerald-700 font-medium">{dep.status}</span>
                </div>
                <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1 border-t border-slate-200/60">
                  <span>{dep.type}</span>
                  <span>{formatDate(dep.date)}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* RIGHT COLUMN: Disbursements (Outflows) */}
        <div className="lg:col-span-7 bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                <ArrowUpRight className="w-4 h-4 text-blue-600" />
                Outgoing Disbursement Schedule
              </h3>
              <p className="text-[11px] text-slate-500">Payoffs, commissions, taxes, recording, and net seller proceeds.</p>
            </div>
            <button
              onClick={() => setShowAddDisbModal(true)}
              className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg no-print"
            >
              <Plus className="w-3 h-3" />
              <span>Add Payee</span>
            </button>
          </div>

          <div className="space-y-3">
            {order.disbursements.map((item) => (
              <div key={item.id} className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs space-y-2">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <span className="font-bold text-slate-900 block">{item.payee}</span>
                    <span className="text-[11px] text-slate-500">
                      {item.category} · {item.method}
                    </span>
                  </div>
                  <div className="text-right">
                    <span className="font-mono font-bold text-slate-900 text-sm tabular-nums block">
                      {formatCurrency(item.amount)}
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">
                      Acct: {item.accountNumberMasked}
                    </span>
                  </div>
                </div>

                {/* Wire Fraud Verification Strip */}
                <div className="pt-2 border-t border-slate-200 flex items-center justify-between text-[11px]">
                  {item.method === 'Wire Transfer' ? (
                    item.wireFraudVerified ? (
                      <span className="inline-flex items-center gap-1 text-emerald-700 font-medium">
                        <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                        Wire Verified: {item.wireFraudVerifiedBy}
                      </span>
                    ) : (
                      <button
                        onClick={() => {
                          setVerifyingItem(item);
                          setCallbackConfirmed(false);
                        }}
                        className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-red-100 hover:bg-red-200 text-red-800 font-semibold text-[10px] transition-colors"
                      >
                        <ShieldAlert className="w-3 h-3 text-red-600" />
                        <span>Perform Verbal Wire Callback Verification</span>
                      </button>
                    )
                  ) : (
                    <span className="text-slate-500 font-mono text-[10px]">
                      {item.checkNumber ? `Check #: ${item.checkNumber}` : 'Electronic Transfer'}
                    </span>
                  )}

                  <span className={`text-[10px] font-semibold px-2 py-0.5 rounded ${
                    item.status === 'Disbursed'
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-blue-100 text-blue-800'
                  }`}>
                    {item.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Wire Fraud Verification Modal */}
      {verifyingItem && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl border border-red-300 max-w-lg w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center gap-2 text-red-600 font-bold border-b border-red-100 pb-3">
              <ShieldAlert className="w-5 h-5 text-red-600" />
              <h4 className="text-sm uppercase tracking-wide">
                ALTA Wire Fraud Prevention Callback Verification
              </h4>
            </div>

            <div className="bg-red-50 p-3 rounded-lg border border-red-200 text-xs text-red-950 space-y-1">
              <p className="font-semibold">Payee Wire Verification Details:</p>
              <p>Payee: <strong>{verifyingItem.payee}</strong></p>
              <p>Amount: <strong>{formatCurrency(verifyingItem.amount)}</strong></p>
              <p>Masked Routing: <strong>{verifyingItem.routingNumberMasked}</strong> | Account: <strong>{verifyingItem.accountNumberMasked}</strong></p>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-xs font-medium text-slate-700 block mb-1">
                  Trusted Telephone Number Called (Independently Verified)
                </label>
                <input
                  type="text"
                  value={callbackNumber}
                  onChange={(e) => setCallbackNumber(e.target.value)}
                  className="w-full text-xs p-2 bg-slate-50 border border-slate-300 rounded-lg font-mono"
                  placeholder="(512) 555-0841"
                  required
                />
              </div>

              <div>
                <label className="text-xs font-medium text-slate-700 block mb-1">
                  Settlement Officer Name
                </label>
                <input
                  type="text"
                  value={officerName}
                  onChange={(e) => setOfficerName(e.target.value)}
                  className="w-full text-xs p-2 bg-slate-50 border border-slate-300 rounded-lg"
                  required
                />
              </div>

              <div className="p-3 bg-slate-100 rounded-lg border border-slate-200">
                <label className="flex items-start gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={callbackConfirmed}
                    onChange={(e) => setCallbackConfirmed(e.target.checked)}
                    className="mt-0.5 rounded text-emerald-600 focus:ring-emerald-500"
                  />
                  <span className="text-[11px] text-slate-700 leading-normal font-medium">
                    I personally conducted a verbal telephone callback to the verified contact person at the phone number above (not from the wire instruction email body) and confirmed the exact bank name, routing number, and account number.
                  </span>
                </label>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-200">
              <button
                type="button"
                onClick={() => setVerifyingItem(null)}
                className="px-3 py-1.5 text-xs font-medium text-slate-600 hover:text-slate-900"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={!callbackConfirmed}
                onClick={handleConfirmWireVerification}
                className={`px-4 py-2 text-xs font-bold rounded-lg shadow-sm ${
                  callbackConfirmed
                    ? 'bg-emerald-600 hover:bg-emerald-500 text-white cursor-pointer'
                    : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                }`}
              >
                Certify Wire Instructions & Clear
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add Deposit Modal */}
      {showAddDepositModal && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl border border-slate-200 max-w-md w-full p-6 shadow-2xl">
            <h4 className="text-base font-bold text-slate-900 mb-3">Record Incoming Escrow Deposit</h4>
            <form onSubmit={handleSaveDeposit} className="space-y-4">
              <div>
                <label className="text-xs font-medium text-slate-700 block mb-1">Source / Remitter</label>
                <input
                  type="text"
                  placeholder="e.g. David Vance (Cash to Close)"
                  value={depSource}
                  onChange={(e) => setDepSource(e.target.value)}
                  className="w-full text-xs p-2 bg-slate-50 border border-slate-300 rounded-lg"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-medium text-slate-700 block mb-1">Amount ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    placeholder="87801.00"
                    value={depAmount}
                    onChange={(e) => setDepAmount(e.target.value)}
                    className="w-full text-xs p-2 bg-slate-50 border border-slate-300 rounded-lg font-mono"
                    required
                  />
                </div>
                <div>
                  <label className="text-xs font-medium text-slate-700 block mb-1">Deposit Type</label>
                  <select
                    value={depType}
                    onChange={(e) => setDepType(e.target.value as EscrowDeposit['type'])}
                    className="w-full text-xs p-2 bg-slate-50 border border-slate-300 rounded-lg"
                  >
                    <option value="Wire Transfer">Wire Transfer</option>
                    <option value="Cashier Check">Cashier Check</option>
                    <option value="ACH / Direct Deposit">ACH Deposit</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-xs font-medium text-slate-700 block mb-1">Reference / Fedwire Number</label>
                <input
                  type="text"
                  placeholder="FEDWIRE-2026-99410"
                  value={depRef}
                  onChange={(e) => setDepRef(e.target.value)}
                  className="w-full text-xs p-2 bg-slate-50 border border-slate-300 rounded-lg font-mono"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddDepositModal(false)}
                  className="px-3 py-1.5 text-xs font-medium text-slate-600 hover:text-slate-900"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg"
                >
                  Save Deposit
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Disbursement Modal */}
      {showAddDisbModal && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl border border-slate-200 max-w-md w-full p-6 shadow-2xl">
            <h4 className="text-base font-bold text-slate-900 mb-3">Add Outgoing Disbursement Payee</h4>
            <form onSubmit={handleSaveDisbursement} className="space-y-4">
              <div>
                <label className="text-xs font-medium text-slate-700 block mb-1">Category</label>
                <select
                  value={disbCategory}
                  onChange={(e) => setDisbCategory(e.target.value as DisbursementItem['category'])}
                  className="w-full text-xs p-2 bg-slate-50 border border-slate-300 rounded-lg"
                >
                  <option value="Mortgage Payoff">Mortgage Payoff</option>
                  <option value="Seller Net Proceeds">Seller Net Proceeds</option>
                  <option value="Broker Commission">Broker Commission</option>
                  <option value="Taxes">Property Taxes / County Collector</option>
                  <option value="Recording Fee">Recording Fee / County Clerk</option>
                  <option value="Title Premium">Underwriter Title Premium</option>
                  <option value="Escrow Settlement Fee">Settlement & Escrow Fee</option>
                  <option value="HOA Transfer">HOA Transfer / Dues</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-medium text-slate-700 block mb-1">Payee Name</label>
                <input
                  type="text"
                  placeholder="e.g. JPMorgan Chase Bank Payoff Dept"
                  value={disbPayee}
                  onChange={(e) => setDisbPayee(e.target.value)}
                  className="w-full text-xs p-2 bg-slate-50 border border-slate-300 rounded-lg"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-medium text-slate-700 block mb-1">Amount ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    placeholder="250000.00"
                    value={disbAmount}
                    onChange={(e) => setDisbAmount(e.target.value)}
                    className="w-full text-xs p-2 bg-slate-50 border border-slate-300 rounded-lg font-mono"
                    required
                  />
                </div>
                <div>
                  <label className="text-xs font-medium text-slate-700 block mb-1">Disbursement Method</label>
                  <select
                    value={disbMethod}
                    onChange={(e) => setDisbMethod(e.target.value as DisbursementItem['method'])}
                    className="w-full text-xs p-2 bg-slate-50 border border-slate-300 rounded-lg"
                  >
                    <option value="Wire Transfer">Wire Transfer</option>
                    <option value="Trust Account Check">Trust Check</option>
                    <option value="Electronic Recording ACH">ACH / E-Recording</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-medium text-slate-700 block mb-1">Routing Number</label>
                  <input
                    type="text"
                    value={disbRouting}
                    onChange={(e) => setDisbRouting(e.target.value)}
                    className="w-full text-xs p-2 bg-slate-50 border border-slate-300 rounded-lg font-mono"
                  />
                </div>
                <div>
                  <label className="text-xs font-medium text-slate-700 block mb-1">Account Number</label>
                  <input
                    type="text"
                    value={disbAccount}
                    onChange={(e) => setDisbAccount(e.target.value)}
                    className="w-full text-xs p-2 bg-slate-50 border border-slate-300 rounded-lg font-mono"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddDisbModal(false)}
                  className="px-3 py-1.5 text-xs font-medium text-slate-600 hover:text-slate-900"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg"
                >
                  Save Payee
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
