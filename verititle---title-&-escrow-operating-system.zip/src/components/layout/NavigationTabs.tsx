import React from 'react';
import { 
  FolderKanban, 
  FileSpreadsheet, 
  PenTool, 
  DollarSign, 
  FileCheck2,
  ScrollText,
  ShieldCheck
} from 'lucide-react';
import { Order } from '../../types/titleEscrow';

interface NavigationTabsProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  activeOrder: Order | null;
}

export const NavigationTabs: React.FC<NavigationTabsProps> = ({
  activeTab,
  setActiveTab,
  activeOrder,
}) => {
  const tabs = [
    {
      id: 'pipeline',
      label: 'Order Pipeline',
      icon: FolderKanban,
      description: 'Active title files & intake',
    },
    {
      id: 'order-detail',
      label: 'File Workspace',
      icon: ScrollText,
      description: activeOrder ? `${activeOrder.fileNumber}` : 'Selected file details',
    },
    {
      id: 'doc-prep',
      label: 'Doc Prep & ALTA',
      icon: FileSpreadsheet,
      description: 'ALTA Settlement, Deeds & Commitments',
    },
    {
      id: 'closing',
      label: 'Closing Room',
      icon: PenTool,
      description: 'Notary & Signatures',
      badge: activeOrder?.closingSession?.status,
    },
    {
      id: 'disbursement',
      label: 'Escrow & Disbursement',
      icon: DollarSign,
      description: 'Trust Ledger & Balancing',
      badge: activeOrder?.escrowBalanced ? 'Balanced' : 'Pending',
    },
    {
      id: 'compliance',
      label: 'ALTA Best Practices',
      icon: ShieldCheck,
      description: '7 Pillars Compliance',
    },
  ];

  return (
    <div className="bg-white border-b border-slate-200 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center space-x-1 sm:space-x-4 overflow-x-auto py-2 scrollbar-none">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-3 py-2 text-xs sm:text-sm font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                  isActive
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-emerald-400' : 'text-slate-500'}`} />
                <span>{tab.label}</span>
                {tab.id === 'order-detail' && activeOrder && (
                  <span className={`text-[11px] font-mono px-1.5 py-0.5 rounded ${
                    isActive ? 'bg-slate-800 text-emerald-300' : 'bg-slate-100 text-slate-700'
                  }`}>
                    {activeOrder.fileNumber}
                  </span>
                )}
                {tab.id === 'disbursement' && activeOrder && (
                  <span className={`text-[10px] uppercase font-mono px-1.5 py-0.5 rounded ${
                    isActive
                      ? 'bg-emerald-800 text-emerald-200'
                      : 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                  }`}>
                    $0.00 Bal
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
