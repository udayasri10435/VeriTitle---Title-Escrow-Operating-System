import React from 'react';
import { 
  Building2, 
  FilePlus, 
  Calculator, 
  ShieldCheck, 
  Search,
  CheckCircle2,
  FileText
} from 'lucide-react';
import { Order } from '../../types/titleEscrow';

interface HeaderProps {
  orders: Order[];
  activeOrder: Order | null;
  onSelectOrder: (order: Order) => void;
  onOpenNewOrder: () => void;
  onOpenCalculator: () => void;
  onOpenCompliance: () => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  orders,
  activeOrder,
  onSelectOrder,
  onOpenNewOrder,
  onOpenCalculator,
  onOpenCompliance,
  activeTab,
  setActiveTab,
}) => {
  return (
    <header className="bg-slate-900 text-white border-b border-slate-800 sticky top-0 z-30 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Zone 1: Single text element wordmark with icon */}
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-emerald-600 flex items-center justify-center font-bold text-white shadow-inner">
              <Building2 className="w-5 h-5 text-white" />
            </div>
            <div>
              <span className="text-lg font-bold tracking-tight text-white flex items-center gap-2">
                VeriTitle OS
                <span className="text-xs font-normal text-emerald-400 bg-emerald-950/70 border border-emerald-800/60 px-2 py-0.5 rounded">
                  Title & Escrow
                </span>
              </span>
            </div>
          </div>

          {/* Zone 2: Active File Selector & Quick Search */}
          <div className="hidden md:flex items-center gap-4">
            <div className="flex items-center gap-2 bg-slate-800/80 border border-slate-700/80 rounded-lg px-3 py-1.5 text-xs text-slate-300">
              <span className="text-slate-400 font-medium">Active File:</span>
              <select
                aria-label="Active Title Order File"
                value={activeOrder?.id || ''}
                onChange={(e) => {
                  const found = orders.find((o) => o.id === e.target.value);
                  if (found) onSelectOrder(found);
                }}
                className="bg-transparent text-white font-mono font-medium focus:outline-none cursor-pointer"
              >
                {orders.map((o) => (
                  <option key={o.id} value={o.id} className="bg-slate-900 text-white">
                    {o.fileNumber} · {o.property.address.split(',')[0]} ({o.status})
                  </option>
                ))}
              </select>
            </div>

            {activeOrder && (
              <div className="flex items-center gap-2 text-xs text-slate-400">
                <span className="text-slate-200 font-medium">{activeOrder.property.city}, {activeOrder.property.state}</span>
                <span>·</span>
                <span className="text-emerald-400 font-mono flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  {activeOrder.status}
                </span>
              </div>
            )}
          </div>

          {/* Zone 3: Actions */}
          <div className="flex items-center gap-2 sm:gap-3">
            <button
              onClick={onOpenCalculator}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg transition-colors whitespace-nowrap"
              title="Title Premium & Settlement Fee Calculator"
            >
              <Calculator className="w-3.5 h-3.5 text-emerald-400" />
              <span className="hidden sm:inline">Rate Calc</span>
            </button>

            <button
              onClick={onOpenCompliance}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg transition-colors whitespace-nowrap"
              title="ALTA Best Practices 7 Pillars Audit"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-blue-400" />
              <span className="hidden sm:inline">ALTA Audit</span>
            </button>

            <button
              onClick={onOpenNewOrder}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg transition-colors shadow-sm whitespace-nowrap"
            >
              <FilePlus className="w-3.5 h-3.5" />
              <span>+ New Order</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
