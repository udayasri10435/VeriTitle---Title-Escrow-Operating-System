import React, { useState } from 'react';
import { X, Building2, User, DollarSign, Calendar, MapPin, Check } from 'lucide-react';
import { Order, TransactionType, Underwriter } from '../../types/titleEscrow';
import { recalculateAltaStatement } from '../../utils/formatters';

interface NewOrderModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveOrder: (newOrder: Order) => void;
  existingCount: number;
}

export const NewOrderModal: React.FC<NewOrderModalProps> = ({
  isOpen,
  onClose,
  onSaveOrder,
  existingCount,
}) => {
  const [fileNumber] = useState(`VT-2026-${8950 + existingCount}`);
  const [type, setType] = useState<TransactionType>('Residential Purchase');
  const [underwriter, setUnderwriter] = useState<Underwriter>('First American Title Insurance Co.');
  const [targetClosingDate, setTargetClosingDate] = useState('2026-10-15');
  
  // Property
  const [address, setAddress] = useState('510 South Congress Avenue');
  const [city, setCity] = useState('Austin');
  const [state, setState] = useState('TX');
  const [zip, setZip] = useState('78704');
  const [county, setCounty] = useState('Travis');
  const [parcelId, setParcelId] = useState('0204-11-0941');
  const [legalDescription, setLegalDescription] = useState('Lot 8, Block 4, South Congress Park Addition, Travis County, Texas.');

  // Financials
  const [purchasePrice, setPurchasePrice] = useState(625000);
  const [loanAmount, setLoanAmount] = useState(500000);
  const [earnestMoney, setEarnestMoney] = useState(20000);

  // Parties
  const [buyerName, setBuyerName] = useState('Michael T. Sterling');
  const [buyerEmail, setBuyerEmail] = useState('m.sterling@example.com');
  const [buyerPhone, setBuyerPhone] = useState('(512) 555-4091');

  const [sellerName, setSellerName] = useState('Jennifer L. Ross');
  const [sellerEmail, setSellerEmail] = useState('jennifer.ross@example.com');
  const [sellerPhone, setSellerPhone] = useState('(512) 555-7819');

  const [lenderName, setLenderName] = useState('Austin Capital Bank');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const newOrderRaw: Order = {
      id: `order-${Date.now()}`,
      fileNumber,
      orderDate: new Date().toISOString().split('T')[0],
      targetClosingDate,
      disbursementDate: targetClosingDate,
      type,
      status: 'Intake / Open',
      underwriter,
      policyNumber: `POL-${state}-${Math.floor(100000 + Math.random() * 900000)}`,
      purchasePrice: Number(purchasePrice) || 0,
      loanAmount: Number(loanAmount) || 0,
      earnestMoney: Number(earnestMoney) || 0,
      escrowBalanced: true,
      disbursementAuthorized: false,
      property: {
        address,
        city,
        state,
        zip,
        county,
        parcelId,
        propertyType: 'Single Family Residence',
        legalDescription,
      },
      parties: [
        {
          id: `p-${Date.now()}-1`,
          role: type === 'Residential Refinance' ? 'Borrower' : 'Buyer',
          name: buyerName,
          email: buyerEmail,
          phone: buyerPhone,
          address: `${address}, ${city}, ${state} ${zip}`,
        },
        {
          id: `p-${Date.now()}-2`,
          role: 'Seller',
          name: sellerName,
          email: sellerEmail,
          phone: sellerPhone,
          address: `${address}, ${city}, ${state} ${zip}`,
        },
        {
          id: `p-${Date.now()}-3`,
          role: 'Lender',
          name: lenderName,
          company: lenderName,
          email: 'closings@lender.com',
          phone: '(800) 555-0100',
        },
        {
          id: `p-${Date.now()}-4`,
          role: 'Settlement Officer',
          name: 'Katherine Reed, Escrow Officer',
          company: 'VeriTitle Settlement Services',
          email: 'kreed@verititle.com',
          phone: '(512) 890-4100',
        },
      ],
      titleRequirements: [
        {
          id: `req-${Date.now()}-1`,
          code: 'REQ-01',
          category: 'Lien / Mortgage',
          description: 'Obtain written payoff verification demand from current lienholder.',
          status: 'Pending',
        },
        {
          id: `req-${Date.now()}-2`,
          code: 'REQ-02',
          category: 'Affidavit',
          description: "Execute standard Owner's Title Affidavit and FIRPTA Non-Foreign Certification.",
          status: 'Pending',
        },
        {
          id: `req-${Date.now()}-3`,
          code: 'REQ-03',
          category: 'Taxes',
          description: 'Obtain current county and municipal tax certificate confirming zero delinquent taxes.',
          status: 'Pending',
        },
      ],
      titleExceptions: [
        {
          id: `exc-${Date.now()}-1`,
          itemNumber: 1,
          type: 'Standard',
          description: `Taxes for the current year ${new Date().getFullYear()} not yet due and payable.`,
        },
      ],
      altaStatement: {
        fileNumber,
        settlementDate: targetClosingDate,
        disbursementDate: targetClosingDate,
        purchasePrice: Number(purchasePrice) || 0,
        loanAmount: Number(loanAmount) || 0,
        earnestMoney: Number(earnestMoney) || 0,
        borrowerTotalDebits: 0,
        borrowerTotalCredits: 0,
        borrowerDueFromOrTo: 0,
        sellerTotalDebits: 0,
        sellerTotalCredits: 0,
        sellerDueToOrFrom: 0,
        lineItems: [
          {
            id: `li-${Date.now()}-1`,
            section: '100_Financial',
            lineCode: '101',
            description: 'Sale Price of Real Property',
            payeeOrPayor: sellerName,
            borrowerDebit: Number(purchasePrice) || 0,
            sellerCredit: Number(purchasePrice) || 0,
          },
          {
            id: `li-${Date.now()}-2`,
            section: '100_Financial',
            lineCode: '102',
            description: 'Earnest Money Escrow Deposit',
            payeeOrPayor: 'VeriTitle Escrow Trust',
            borrowerCredit: Number(earnestMoney) || 0,
          },
          {
            id: `li-${Date.now()}-3`,
            section: '100_Financial',
            lineCode: '103',
            description: 'New Mortgage Loan Amount',
            payeeOrPayor: lenderName,
            borrowerCredit: Number(loanAmount) || 0,
          },
          {
            id: `li-${Date.now()}-4`,
            section: '500_TitleCharges',
            lineCode: '501',
            description: "Owner's Title Insurance Policy",
            payeeOrPayor: underwriter,
            sellerDebit: 2950,
          },
          {
            id: `li-${Date.now()}-5`,
            section: '500_TitleCharges',
            lineCode: '502',
            description: 'Loan Title Insurance Policy',
            payeeOrPayor: underwriter,
            borrowerDebit: 325,
          },
          {
            id: `li-${Date.now()}-6`,
            section: '500_TitleCharges',
            lineCode: '504',
            description: 'Escrow / Settlement Closing Fee',
            payeeOrPayor: 'VeriTitle Settlement Services',
            borrowerDebit: 350,
            sellerDebit: 350,
          },
        ],
      },
      escrowDeposits: [
        {
          id: `dep-${Date.now()}-1`,
          date: new Date().toISOString().split('T')[0],
          source: buyerName,
          referenceNumber: 'INITIAL-EMD-WIRE',
          type: 'Wire Transfer',
          amount: Number(earnestMoney) || 0,
          status: 'Cleared',
          verifiedBy: 'Escrow Intake Desk',
        },
      ],
      disbursements: [],
      documents: [
        {
          id: `doc-${Date.now()}-1`,
          title: 'ALTA Combined Settlement Statement',
          category: 'Settlement Statement',
          totalPages: 4,
          status: 'Ready for Review',
          requiredSigners: ['Buyer', 'Seller', 'Settlement Agent'],
          signaturesCollected: [],
          lastModified: new Date().toISOString(),
        },
        {
          id: `doc-${Date.now()}-2`,
          title: 'General Warranty Deed',
          category: 'Deed',
          totalPages: 3,
          status: 'Draft',
          requiredSigners: ['Seller', 'Notary'],
          signaturesCollected: [],
          lastModified: new Date().toISOString(),
        },
      ],
      closingSession: {
        id: `sess-${Date.now()}`,
        fileNumber,
        modality: 'In-Person Settlement',
        scheduledDate: targetClosingDate,
        scheduledTime: '10:00 AM CST',
        locationOrPlatform: 'VeriTitle Settlement Conference Room',
        notaryName: 'Katherine Reed (Notary Public)',
        notaryCommissionNumber: 'TX-13049921',
        status: 'Scheduled',
      },
      internalNotes: [
        `${new Date().toISOString().split('T')[0]}: Title order opened via Intake Desk. Initial title search requested.`,
      ],
    };

    const finalOrder = {
      ...newOrderRaw,
      altaStatement: recalculateAltaStatement(newOrderRaw.altaStatement),
    };

    onSaveOrder(finalOrder);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center z-50 p-4 overflow-y-auto">
      <div className="bg-white rounded-xl border border-slate-200 max-w-3xl w-full shadow-2xl my-8 overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold">New Title & Escrow Order Intake</h3>
            <p className="text-xs text-slate-400">File #: <span className="font-mono text-emerald-400">{fileNumber}</span></p>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white p-1">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6 max-h-[80vh] overflow-y-auto">
          {/* Transaction & Underwriter */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="text-xs font-medium text-slate-700 block mb-1">Transaction Type</label>
              <select
                value={type}
                onChange={(e) => setType(e.target.value as TransactionType)}
                className="w-full text-xs p-2 bg-slate-50 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-900"
              >
                <option value="Residential Purchase">Residential Purchase</option>
                <option value="Residential Refinance">Residential Refinance</option>
                <option value="Commercial Purchase">Commercial Purchase</option>
                <option value="Cash Purchase">Cash Purchase</option>
              </select>
            </div>

            <div>
              <label className="text-xs font-medium text-slate-700 block mb-1">Underwriter</label>
              <select
                value={underwriter}
                onChange={(e) => setUnderwriter(e.target.value as Underwriter)}
                className="w-full text-xs p-2 bg-slate-50 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-900"
              >
                <option value="First American Title Insurance Co.">First American Title</option>
                <option value="Fidelity National Title">Fidelity National Title</option>
                <option value="Old Republic National Title">Old Republic Title</option>
                <option value="Stewart Title Guaranty">Stewart Title Guaranty</option>
                <option value="Chicago Title Insurance Co.">Chicago Title</option>
              </select>
            </div>

            <div>
              <label className="text-xs font-medium text-slate-700 block mb-1">Target Closing Date</label>
              <input
                type="date"
                value={targetClosingDate}
                onChange={(e) => setTargetClosingDate(e.target.value)}
                className="w-full text-xs p-2 bg-slate-50 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-900"
                required
              />
            </div>
          </div>

          {/* Property Details */}
          <div className="border-t border-slate-200 pt-4 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">Property Details</h4>
            
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="sm:col-span-2">
                <label className="text-xs font-medium text-slate-700 block mb-1">Street Address</label>
                <input
                  type="text"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="w-full text-xs p-2 bg-slate-50 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-900"
                  required
                />
              </div>
              <div>
                <label className="text-xs font-medium text-slate-700 block mb-1">Tax Parcel ID / APN</label>
                <input
                  type="text"
                  value={parcelId}
                  onChange={(e) => setParcelId(e.target.value)}
                  className="w-full text-xs p-2 bg-slate-50 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-900 font-mono"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div>
                <label className="text-xs font-medium text-slate-700 block mb-1">City</label>
                <input
                  type="text"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  className="w-full text-xs p-2 bg-slate-50 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-900"
                  required
                />
              </div>
              <div>
                <label className="text-xs font-medium text-slate-700 block mb-1">State</label>
                <input
                  type="text"
                  value={state}
                  onChange={(e) => setState(e.target.value)}
                  className="w-full text-xs p-2 bg-slate-50 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-900"
                  required
                />
              </div>
              <div>
                <label className="text-xs font-medium text-slate-700 block mb-1">ZIP</label>
                <input
                  type="text"
                  value={zip}
                  onChange={(e) => setZip(e.target.value)}
                  className="w-full text-xs p-2 bg-slate-50 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-900 font-mono"
                  required
                />
              </div>
              <div>
                <label className="text-xs font-medium text-slate-700 block mb-1">County</label>
                <input
                  type="text"
                  value={county}
                  onChange={(e) => setCounty(e.target.value)}
                  className="w-full text-xs p-2 bg-slate-50 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-900"
                  required
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-medium text-slate-700 block mb-1">Legal Description</label>
              <textarea
                rows={2}
                value={legalDescription}
                onChange={(e) => setLegalDescription(e.target.value)}
                className="w-full text-xs p-2 bg-slate-50 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-900 font-mono"
              />
            </div>
          </div>

          {/* Financials */}
          <div className="border-t border-slate-200 pt-4 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">Transaction Financials</h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="text-xs font-medium text-slate-700 block mb-1">Purchase Price ($)</label>
                <input
                  type="number"
                  value={purchasePrice}
                  onChange={(e) => setPurchasePrice(Number(e.target.value))}
                  className="w-full text-xs p-2 bg-slate-50 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-900 font-mono"
                  min="0"
                />
              </div>
              <div>
                <label className="text-xs font-medium text-slate-700 block mb-1">Loan Amount ($)</label>
                <input
                  type="number"
                  value={loanAmount}
                  onChange={(e) => setLoanAmount(Number(e.target.value))}
                  className="w-full text-xs p-2 bg-slate-50 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-900 font-mono"
                  min="0"
                />
              </div>
              <div>
                <label className="text-xs font-medium text-slate-700 block mb-1">Earnest Money Deposit ($)</label>
                <input
                  type="number"
                  value={earnestMoney}
                  onChange={(e) => setEarnestMoney(Number(e.target.value))}
                  className="w-full text-xs p-2 bg-slate-50 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-900 font-mono"
                  min="0"
                />
              </div>
            </div>
          </div>

          {/* Parties */}
          <div className="border-t border-slate-200 pt-4 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">Primary Parties</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-2">
                <span className="text-xs font-semibold text-slate-800 block">Buyer / Borrower</span>
                <input
                  type="text"
                  placeholder="Full Name"
                  value={buyerName}
                  onChange={(e) => setBuyerName(e.target.value)}
                  className="w-full text-xs p-2 bg-white border border-slate-300 rounded-lg"
                  required
                />
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="email"
                    placeholder="Email"
                    value={buyerEmail}
                    onChange={(e) => setBuyerEmail(e.target.value)}
                    className="w-full text-xs p-2 bg-white border border-slate-300 rounded-lg"
                  />
                  <input
                    type="text"
                    placeholder="Phone"
                    value={buyerPhone}
                    onChange={(e) => setBuyerPhone(e.target.value)}
                    className="w-full text-xs p-2 bg-white border border-slate-300 rounded-lg font-mono"
                  />
                </div>
              </div>

              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-2">
                <span className="text-xs font-semibold text-slate-800 block">Seller</span>
                <input
                  type="text"
                  placeholder="Full Name"
                  value={sellerName}
                  onChange={(e) => setSellerName(e.target.value)}
                  className="w-full text-xs p-2 bg-white border border-slate-300 rounded-lg"
                  required
                />
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="email"
                    placeholder="Email"
                    value={sellerEmail}
                    onChange={(e) => setSellerEmail(e.target.value)}
                    className="w-full text-xs p-2 bg-white border border-slate-300 rounded-lg"
                  />
                  <input
                    type="text"
                    placeholder="Phone"
                    value={sellerPhone}
                    onChange={(e) => setSellerPhone(e.target.value)}
                    className="w-full text-xs p-2 bg-white border border-slate-300 rounded-lg font-mono"
                  />
                </div>
              </div>
            </div>

            <div>
              <label className="text-xs font-medium text-slate-700 block mb-1">Mortgage Lender Institution</label>
              <input
                type="text"
                value={lenderName}
                onChange={(e) => setLenderName(e.target.value)}
                className="w-full text-xs p-2 bg-slate-50 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-900"
              />
            </div>
          </div>

          {/* Footer buttons */}
          <div className="border-t border-slate-200 pt-4 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-600 hover:text-slate-900"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg shadow-sm"
            >
              Create Title & Escrow Order
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
