import React, { useState, useMemo } from 'react';
import { 
  Search, 
  Filter, 
  Calendar, 
  MapPin, 
  ArrowRight, 
  Building, 
  CheckCircle2, 
  Clock, 
  DollarSign, 
  FileText, 
  Plus, 
  ChevronRight,
  TrendingUp,
  ShieldAlert,
  Layers
} from 'lucide-react';
import { Order, OrderStatus, TransactionType } from '../../types/titleEscrow';
import { formatCurrency, formatDate } from '../../utils/formatters';

interface OrderListProps {
  orders: Order[];
  onSelectOrder: (order: Order, targetTab?: string) => void;
  onOpenNewOrder: () => void;
}

export const OrderList: React.FC<OrderListProps> = ({
  orders,
  onSelectOrder,
  onOpenNewOrder,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [typeFilter, setTypeFilter] = useState<string>('All');
  const [viewMode, setViewMode] = useState<'table' | 'kanban'>('table');

  // Metrics summary
  const metrics = useMemo(() => {
    const totalFiles = orders.length;
    const clearToClose = orders.filter((o) => o.status === 'Clear to Close').length;
    const scheduled = orders.filter((o) => o.status === 'Closing Scheduled' || o.status === 'Clear to Close').length;
    const totalEscrowVolume = orders.reduce((sum, o) => sum + (o.purchasePrice || o.loanAmount || 0), 0);
    return { totalFiles, clearToClose, scheduled, totalEscrowVolume };
  }, [orders]);

  // Filtered orders
  const filteredOrders = useMemo(() => {
    return orders.filter((order) => {
      const matchesSearch =
        order.fileNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
        order.property.address.toLowerCase().includes(searchQuery.toLowerCase()) ||
        order.property.city.toLowerCase().includes(searchQuery.toLowerCase()) ||
        order.parties.some((p) => p.name.toLowerCase().includes(searchQuery.toLowerCase()));

      const matchesStatus = statusFilter === 'All' || order.status === statusFilter;
      const matchesType = typeFilter === 'All' || order.type === typeFilter;

      return matchesSearch && matchesStatus && matchesType;
    });
  }, [orders, searchQuery, statusFilter, typeFilter]);

  const statusColors: Record<OrderStatus, { bg: string; text: string; border: string }> = {
    'Intake / Open': { bg: 'bg-slate-100', text: 'text-slate-800', border: 'border-slate-300' },
    'Title Search & Abstract': { bg: 'bg-amber-50', text: 'text-amber-800', border: 'border-amber-200' },
    'Exam & Commitment Issued': { bg: 'bg-blue-50', text: 'text-blue-800', border: 'border-blue-200' },
    'Clear to Close': { bg: 'bg-emerald-50', text: 'text-emerald-800', border: 'border-emerald-300' },
    'Closing Scheduled': { bg: 'bg-indigo-50', text: 'text-indigo-800', border: 'border-indigo-200' },
    'Closed & Executed': { bg: 'bg-teal-50', text: 'text-teal-800', border: 'border-teal-200' },
    'Disbursed & Recorded': { bg: 'bg-emerald-100', text: 'text-emerald-900', border: 'border-emerald-400' },
    'Policy Issued': { bg: 'bg-purple-50', text: 'text-purple-800', border: 'border-purple-200' },
  };

  const kanbanColumns: OrderStatus[] = [
    'Intake / Open',
    'Title Search & Abstract',
    'Exam & Commitment Issued',
    'Clear to Close',
    'Closing Scheduled',
    'Disbursed & Recorded',
  ];

  return (
    <div className="space-y-6">
      {/* Top Banner / Metrics bar */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500">Active Files</span>
            <Layers className="w-4 h-4 text-slate-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-slate-900">{metrics.totalFiles}</span>
            <span className="text-xs text-slate-500">files in pipeline</span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500">Clear to Close</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-emerald-700">{metrics.clearToClose}</span>
            <span className="text-xs text-slate-500">ready for signing</span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500">Closings Scheduled</span>
            <Calendar className="w-4 h-4 text-indigo-600" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-indigo-700">{metrics.scheduled}</span>
            <span className="text-xs text-slate-500">this month</span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500">Pipeline Volume</span>
            <TrendingUp className="w-4 h-4 text-blue-600" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-slate-900">{formatCurrency(metrics.totalEscrowVolume)}</span>
          </div>
        </div>
      </div>

      {/* Control bar: Search, Filters, View Mode */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex flex-1 items-center gap-3">
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search by file #, address, buyer, seller..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 text-sm bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900 focus:bg-white transition-all"
            />
          </div>

          {/* Status selector */}
          <select
            aria-label="Filter orders by status"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="text-xs font-medium bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-slate-700 focus:outline-none focus:ring-2 focus:ring-slate-900"
          >
            <option value="All">All Statuses</option>
            <option value="Intake / Open">Intake / Open</option>
            <option value="Title Search & Abstract">Title Search & Abstract</option>
            <option value="Exam & Commitment Issued">Exam & Commitment Issued</option>
            <option value="Clear to Close">Clear to Close</option>
            <option value="Closing Scheduled">Closing Scheduled</option>
            <option value="Disbursed & Recorded">Disbursed & Recorded</option>
          </select>

          {/* Type selector */}
          <select
            aria-label="Filter orders by transaction type"
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            className="text-xs font-medium bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-slate-700 focus:outline-none focus:ring-2 focus:ring-slate-900 hidden sm:block"
          >
            <option value="All">All Types</option>
            <option value="Residential Purchase">Residential Purchase</option>
            <option value="Residential Refinance">Residential Refinance</option>
            <option value="Commercial Purchase">Commercial Purchase</option>
            <option value="Cash Purchase">Cash Purchase</option>
          </select>
        </div>

        {/* View mode toggle + Add button */}
        <div className="flex items-center gap-2 shrink-0">
          <div className="flex items-center bg-slate-100 p-0.5 rounded-lg border border-slate-200">
            <button
              onClick={() => setViewMode('table')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                viewMode === 'table' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Table View
            </button>
            <button
              onClick={() => setViewMode('kanban')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                viewMode === 'kanban' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Pipeline Board
            </button>
          </div>

          <button
            onClick={onOpenNewOrder}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New File</span>
          </button>
        </div>
      </div>

      {/* Main View: Table or Kanban */}
      {viewMode === 'table' ? (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50/80 border-b border-slate-200 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                  <th className="py-3 px-4">File # & Property</th>
                  <th className="py-3 px-4">Transaction / Underwriter</th>
                  <th className="py-3 px-4">Parties</th>
                  <th className="py-3 px-4 text-right">Purchase Price / Loan</th>
                  <th className="py-3 px-4">Target Closing</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 text-sm">
                {filteredOrders.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="py-12 text-center text-slate-500">
                      <p className="text-base font-medium">No title orders match your search criteria</p>
                      <p className="text-xs text-slate-400 mt-1">Try modifying your search or reset the filters</p>
                      <button
                        onClick={() => {
                          setSearchQuery('');
                          setStatusFilter('All');
                          setTypeFilter('All');
                        }}
                        className="mt-3 px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg"
                      >
                        Reset Filters
                      </button>
                    </td>
                  </tr>
                ) : (
                  filteredOrders.map((order) => {
                    const buyer = order.parties.find((p) => p.role === 'Buyer' || p.role === 'Borrower')?.name || '—';
                    const seller = order.parties.find((p) => p.role === 'Seller')?.name || '—';
                    const statusStyle = statusColors[order.status] || { bg: 'bg-slate-100', text: 'text-slate-800', border: 'border-slate-200' };

                    return (
                      <tr 
                        key={order.id} 
                        className="hover:bg-slate-50/80 transition-colors group cursor-pointer"
                        onClick={() => onSelectOrder(order, 'order-detail')}
                      >
                        {/* File # & Address */}
                        <td className="py-3 px-4">
                          <div className="font-mono font-semibold text-slate-900 group-hover:text-emerald-700 flex items-center gap-1.5">
                            {order.fileNumber}
                          </div>
                          <div className="text-xs text-slate-600 font-medium truncate max-w-xs mt-0.5">
                            {order.property.address}
                          </div>
                          <div className="text-[11px] text-slate-400">
                            {order.property.city}, {order.property.state} {order.property.zip}
                          </div>
                        </td>

                        {/* Transaction & Underwriter */}
                        <td className="py-3 px-4">
                          <div className="text-xs font-medium text-slate-900">{order.type}</div>
                          <div className="text-[11px] text-slate-500 truncate max-w-[200px] mt-0.5">
                            {order.underwriter.split(' ')[0]} {order.underwriter.split(' ')[1]}
                          </div>
                          <div className="text-[10px] font-mono text-slate-400">
                            APN: {order.property.parcelId}
                          </div>
                        </td>

                        {/* Parties */}
                        <td className="py-3 px-4 text-xs">
                          <div className="text-slate-800">
                            <span className="text-slate-400 font-normal">B:</span> {buyer}
                          </div>
                          {seller !== '—' && (
                            <div className="text-slate-600 text-[11px] mt-0.5">
                              <span className="text-slate-400 font-normal">S:</span> {seller}
                            </div>
                          )}
                        </td>

                        {/* Financial Figures */}
                        <td className="py-3 px-4 text-right">
                          <div className="font-mono font-medium text-slate-900 tabular-nums">
                            {order.purchasePrice > 0 ? formatCurrency(order.purchasePrice) : formatCurrency(order.loanAmount)}
                          </div>
                          {order.loanAmount > 0 && order.purchasePrice > 0 && (
                            <div className="text-[11px] font-mono text-slate-500 tabular-nums">
                              Loan: {formatCurrency(order.loanAmount)}
                            </div>
                          )}
                        </td>

                        {/* Target Closing */}
                        <td className="py-3 px-4 text-xs">
                          <div className="font-medium text-slate-900 flex items-center gap-1">
                            <Calendar className="w-3.5 h-3.5 text-slate-400" />
                            {formatDate(order.targetClosingDate)}
                          </div>
                          <div className="text-[11px] text-slate-500 mt-0.5">
                            {order.closingSession?.modality || 'In-Person'}
                          </div>
                        </td>

                        {/* Status */}
                        <td className="py-3 px-4">
                          <span className={`inline-flex items-center text-xs font-medium px-2.5 py-1 rounded-md border ${statusStyle.bg} ${statusStyle.text} ${statusStyle.border}`}>
                            {order.status}
                          </span>
                        </td>

                        {/* Action buttons */}
                        <td className="py-3 px-4 text-right" onClick={(e) => e.stopPropagation()}>
                          <div className="flex items-center justify-end gap-1">
                            <button
                              onClick={() => onSelectOrder(order, 'doc-prep')}
                              className="px-2.5 py-1 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors"
                              title="ALTA Settlement & Doc Prep"
                            >
                              ALTA
                            </button>
                            <button
                              onClick={() => onSelectOrder(order, 'disbursement')}
                              className="px-2.5 py-1 text-xs font-medium text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-md transition-colors"
                              title="Escrow & Disbursement"
                            >
                              Escrow
                            </button>
                            <button
                              onClick={() => onSelectOrder(order, 'order-detail')}
                              className="p-1 text-slate-400 hover:text-slate-800"
                              title="Open File Workspace"
                            >
                              <ChevronRight className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        /* Kanban Pipeline View */
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4 overflow-x-auto pb-4">
          {kanbanColumns.map((colStatus) => {
            const colOrders = filteredOrders.filter((o) => o.status === colStatus);
            return (
              <div key={colStatus} className="bg-slate-100/70 p-3 rounded-xl border border-slate-200 min-w-[240px] flex flex-col">
                <div className="flex items-center justify-between pb-2 border-b border-slate-200 mb-3">
                  <span className="text-xs font-bold text-slate-800">{colStatus}</span>
                  <span className="text-xs font-mono font-medium bg-white px-2 py-0.5 rounded-full text-slate-600 border border-slate-200">
                    {colOrders.length}
                  </span>
                </div>

                <div className="space-y-3 flex-1 overflow-y-auto max-h-[600px]">
                  {colOrders.map((ord) => (
                    <div
                      key={ord.id}
                      onClick={() => onSelectOrder(ord, 'order-detail')}
                      className="bg-white p-3 rounded-lg border border-slate-200 shadow-xs hover:border-slate-400 transition-all cursor-pointer"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-mono text-xs font-bold text-slate-900">{ord.fileNumber}</span>
                        <span className="text-[10px] font-medium text-slate-500">{ord.property.state}</span>
                      </div>
                      <div className="text-xs font-medium text-slate-800 mt-1 line-clamp-1">
                        {ord.property.address}
                      </div>
                      <div className="text-[11px] text-slate-500 mt-1">
                        {ord.parties.find((p) => p.role === 'Buyer' || p.role === 'Borrower')?.name || 'Buyer'}
                      </div>
                      <div className="mt-2 pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] font-mono">
                        <span className="text-slate-900 font-semibold">{formatCurrency(ord.purchasePrice || ord.loanAmount)}</span>
                        <span className="text-slate-500">{formatDate(ord.targetClosingDate)}</span>
                      </div>
                    </div>
                  ))}

                  {colOrders.length === 0 && (
                    <div className="py-6 text-center text-xs text-slate-400">
                      No files
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
