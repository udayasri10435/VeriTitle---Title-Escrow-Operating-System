import React, { useState } from 'react';
import { 
  Building, 
  MapPin, 
  Calendar, 
  User, 
  CheckCircle2, 
  AlertCircle, 
  Clock, 
  DollarSign, 
  FileSpreadsheet, 
  PenTool, 
  ShieldCheck, 
  Plus, 
  FileText, 
  ArrowRight,
  ExternalLink,
  MessageSquare,
  Send,
  Sparkles
} from 'lucide-react';
import { Order, OrderStatus, TitleRequirement } from '../../types/titleEscrow';
import { formatCurrency, formatDate } from '../../utils/formatters';

interface OrderDetailProps {
  order: Order;
  onUpdateOrder: (updatedOrder: Order) => void;
  onNavigateTab: (tab: string) => void;
}

export const OrderDetail: React.FC<OrderDetailProps> = ({
  order,
  onUpdateOrder,
  onNavigateTab,
}) => {
  const [activeSection, setActiveSection] = useState<'overview' | 'requirements' | 'parties' | 'notes'>('overview');
  const [newNoteText, setNewNoteText] = useState('');
  const [showAddReqModal, setShowAddReqModal] = useState(false);
  const [newReqCode, setNewReqCode] = useState('');
  const [newReqCategory, setNewReqCategory] = useState<TitleRequirement['category']>('Lien / Mortgage');
  const [newReqDesc, setNewReqDesc] = useState('');

  // Handle advancing or changing status
  const handleStatusChange = (newStatus: OrderStatus) => {
    const updated = {
      ...order,
      status: newStatus,
      internalNotes: [
        `${new Date().toISOString().split('T')[0]}: Status changed to ${newStatus}`,
        ...order.internalNotes,
      ],
    };
    onUpdateOrder(updated);
  };

  // Toggle requirement status
  const toggleRequirementStatus = (reqId: string) => {
    const updatedReqs = order.titleRequirements.map((req) => {
      if (req.id === reqId) {
        const nextStatus = req.status === 'Pending' ? 'Satisfied' : req.status === 'Satisfied' ? 'Waived' : 'Pending';
        return {
          ...req,
          status: nextStatus as 'Pending' | 'Satisfied' | 'Waived',
          satisfiedAt: nextStatus === 'Satisfied' ? new Date().toISOString().split('T')[0] : undefined,
        };
      }
      return req;
    });

    const allSatisfied = updatedReqs.every((r) => r.status === 'Satisfied' || r.status === 'Waived');
    const newOrderStatus = allSatisfied && order.status === 'Exam & Commitment Issued' ? 'Clear to Close' : order.status;

    onUpdateOrder({
      ...order,
      status: newOrderStatus,
      titleRequirements: updatedReqs,
    });
  };

  // Add new requirement
  const handleAddRequirement = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newReqDesc) return;

    const newReq: TitleRequirement = {
      id: `req-${Date.now()}`,
      code: newReqCode || `REQ-0${order.titleRequirements.length + 1}`,
      category: newReqCategory,
      description: newReqDesc,
      status: 'Pending',
    };

    onUpdateOrder({
      ...order,
      titleRequirements: [...order.titleRequirements, newReq],
    });

    setNewReqDesc('');
    setNewReqCode('');
    setShowAddReqModal(false);
  };

  // Add new note
  const handleAddNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newNoteText.trim()) return;

    const todayStr = new Date().toISOString().split('T')[0];
    const updatedNotes = [`${todayStr}: ${newNoteText.trim()}`, ...order.internalNotes];

    onUpdateOrder({
      ...order,
      internalNotes: updatedNotes,
    });
    setNewNoteText('');
  };

  const buyer = order.parties.find((p) => p.role === 'Buyer' || p.role === 'Borrower');
  const seller = order.parties.find((p) => p.role === 'Seller');
  const lender = order.parties.find((p) => p.role === 'Lender');

  const pendingRequirementsCount = order.titleRequirements.filter((r) => r.status === 'Pending').length;

  return (
    <div className="space-y-6">
      {/* File Header Bar */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-3">
              <span className="text-2xl font-bold font-mono text-slate-900">{order.fileNumber}</span>
              <span className="text-xs font-semibold px-2.5 py-1 rounded bg-slate-100 text-slate-700 border border-slate-200">
                {order.type}
              </span>
              <div className="flex items-center gap-1.5">
                <span className="text-xs text-slate-500 font-medium">Status:</span>
                <select
                  aria-label="Order status selector"
                  value={order.status}
                  onChange={(e) => handleStatusChange(e.target.value as OrderStatus)}
                  className="text-xs font-semibold bg-emerald-50 text-emerald-800 border border-emerald-300 rounded-lg px-2.5 py-1 focus:outline-none focus:ring-2 focus:ring-emerald-500 cursor-pointer"
                >
                  <option value="Intake / Open">Intake / Open</option>
                  <option value="Title Search & Abstract">Title Search & Abstract</option>
                  <option value="Exam & Commitment Issued">Exam & Commitment Issued</option>
                  <option value="Clear to Close">Clear to Close</option>
                  <option value="Closing Scheduled">Closing Scheduled</option>
                  <option value="Closed & Executed">Closed & Executed</option>
                  <option value="Disbursed & Recorded">Disbursed & Recorded</option>
                  <option value="Policy Issued">Policy Issued</option>
                </select>
              </div>
            </div>

            <p className="text-sm text-slate-600 font-medium mt-1 flex items-center gap-1.5">
              <MapPin className="w-4 h-4 text-slate-400" />
              {order.property.address}, {order.property.city}, {order.property.state} {order.property.zip}
              <span className="text-slate-400 font-normal">({order.property.county} County · APN: {order.property.parcelId})</span>
            </p>
          </div>

          {/* Quick Module Jump Buttons */}
          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={() => onNavigateTab('doc-prep')}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-800 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-lg transition-colors"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-blue-600" />
              <span>ALTA & Doc Prep</span>
            </button>
            <button
              onClick={() => onNavigateTab('closing')}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-800 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-lg transition-colors"
            >
              <PenTool className="w-3.5 h-3.5 text-indigo-600" />
              <span>Closing Room</span>
            </button>
            <button
              onClick={() => onNavigateTab('disbursement')}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg transition-colors shadow-xs"
            >
              <DollarSign className="w-3.5 h-3.5" />
              <span>Escrow Trust Ledger</span>
            </button>
          </div>
        </div>

        {/* Quick Highlights Strip */}
        <div className="mt-5 pt-4 border-t border-slate-100 grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-4 text-xs">
          <div>
            <span className="text-slate-400 block">Purchase Price</span>
            <span className="font-mono font-semibold text-slate-900 text-sm">
              {order.purchasePrice > 0 ? formatCurrency(order.purchasePrice) : 'N/A (Refi)'}
            </span>
          </div>
          <div>
            <span className="text-slate-400 block">Loan Amount</span>
            <span className="font-mono font-semibold text-slate-900 text-sm">
              {order.loanAmount > 0 ? formatCurrency(order.loanAmount) : 'Cash (No Loan)'}
            </span>
          </div>
          <div>
            <span className="text-slate-400 block">Target Closing</span>
            <span className="font-medium text-slate-900 text-sm flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-slate-400" />
              {formatDate(order.targetClosingDate)}
            </span>
          </div>
          <div>
            <span className="text-slate-400 block">Underwriter</span>
            <span className="font-medium text-slate-900 text-xs truncate block" title={order.underwriter}>
              {order.underwriter.split(' ')[0]} {order.underwriter.split(' ')[1]}
            </span>
          </div>
          <div>
            <span className="text-slate-400 block">Title Clearance</span>
            <span className={`font-medium ${pendingRequirementsCount === 0 ? 'text-emerald-600' : 'text-amber-600'}`}>
              {pendingRequirementsCount === 0 ? 'All 5 Cleared' : `${pendingRequirementsCount} Pending`}
            </span>
          </div>
          <div>
            <span className="text-slate-400 block">Escrow Ledger</span>
            <span className="font-mono font-medium text-emerald-600 flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              $0.00 Balanced
            </span>
          </div>
        </div>
      </div>

      {/* Internal Navigation Tabs within Order Workspace */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
        <button
          onClick={() => setActiveSection('overview')}
          className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
            activeSection === 'overview' ? 'bg-slate-900 text-white' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Property & Legal Overview
        </button>
        <button
          onClick={() => setActiveSection('requirements')}
          className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors flex items-center gap-1.5 ${
            activeSection === 'requirements' ? 'bg-slate-900 text-white' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <span>Title Requirements & Clearance</span>
          {pendingRequirementsCount > 0 && (
            <span className="bg-amber-100 text-amber-800 text-[10px] font-mono px-1.5 py-0.2 rounded-full">
              {pendingRequirementsCount}
            </span>
          )}
        </button>
        <button
          onClick={() => setActiveSection('parties')}
          className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
            activeSection === 'parties' ? 'bg-slate-900 text-white' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Parties & Contacts ({order.parties.length})
        </button>
        <button
          onClick={() => setActiveSection('notes')}
          className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
            activeSection === 'notes' ? 'bg-slate-900 text-white' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          File Audit Notes ({order.internalNotes.length})
        </button>
      </div>

      {/* SECTION 1: Property & Legal Overview */}
      {activeSection === 'overview' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
              <h3 className="text-sm font-bold text-slate-900 mb-3 flex items-center gap-2">
                <Building className="w-4 h-4 text-slate-500" />
                Property Identification & Legal Description
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                  <span className="text-slate-400 block font-medium">Physical Address</span>
                  <span className="text-slate-900 font-semibold mt-0.5 block">{order.property.address}</span>
                  <span className="text-slate-600">{order.property.city}, {order.property.state} {order.property.zip}</span>
                </div>

                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                  <span className="text-slate-400 block font-medium">County & Tax Parcel ID (APN)</span>
                  <span className="text-slate-900 font-mono font-semibold mt-0.5 block">{order.property.parcelId}</span>
                  <span className="text-slate-600">{order.property.county} County · {order.property.propertyType}</span>
                </div>
              </div>

              <div className="mt-4 p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs">
                <span className="text-slate-500 font-semibold block mb-1">Official Legal Description (Schedule A)</span>
                <p className="font-mono text-slate-800 leading-relaxed text-[12px] bg-white p-2.5 rounded border border-slate-200 select-all">
                  {order.property.legalDescription}
                </p>
              </div>
            </div>

            {/* Exceptions of Record */}
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
              <h3 className="text-sm font-bold text-slate-900 mb-3 flex items-center gap-2">
                <FileText className="w-4 h-4 text-slate-500" />
                Schedule B-II: Title Exceptions Not Covered
              </h3>

              <div className="space-y-2">
                {order.titleExceptions.length === 0 ? (
                  <p className="text-xs text-slate-400 py-3">No specific exceptions noted on preliminary abstract.</p>
                ) : (
                  order.titleExceptions.map((exc) => (
                    <div key={exc.id} className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs">
                      <div className="flex items-center gap-2 font-medium text-slate-800">
                        <span className="font-mono text-slate-500">#{exc.itemNumber}</span>
                        <span className="text-slate-400">·</span>
                        <span className="font-semibold text-slate-700">{exc.type}</span>
                      </div>
                      <p className="text-slate-600 mt-1 leading-normal">{exc.description}</p>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>

          {/* Right sidebar: Settlement & Policy Details */}
          <div className="space-y-6">
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
              <h3 className="text-sm font-bold text-slate-900 mb-3 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                Underwriting & Policy
              </h3>

              <div className="space-y-3 text-xs">
                <div>
                  <span className="text-slate-400 block">Underwriter</span>
                  <span className="font-medium text-slate-900">{order.underwriter}</span>
                </div>
                <div>
                  <span className="text-slate-400 block">Underwriter Policy Number</span>
                  <span className="font-mono text-slate-800 font-semibold">{order.policyNumber || 'Pending Issuance'}</span>
                </div>
                <div>
                  <span className="text-slate-400 block">Order Date</span>
                  <span className="text-slate-800">{formatDate(order.orderDate)}</span>
                </div>
                <div>
                  <span className="text-slate-400 block">Disbursement Date</span>
                  <span className="text-slate-800">{formatDate(order.disbursementDate)}</span>
                </div>
                <div>
                  <span className="text-slate-400 block">Settlement Officer</span>
                  <span className="font-medium text-slate-900">
                    {order.parties.find((p) => p.role === 'Settlement Officer')?.name || 'Assigned Officer'}
                  </span>
                </div>
              </div>
            </div>

            {/* Closing Appointment */}
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
              <h3 className="text-sm font-bold text-slate-900 mb-2 flex items-center gap-2">
                <Calendar className="w-4 h-4 text-indigo-600" />
                Closing Session Details
              </h3>
              <div className="text-xs space-y-2 text-slate-700">
                <div className="flex justify-between">
                  <span className="text-slate-400">Modality:</span>
                  <span className="font-semibold text-slate-900">{order.closingSession?.modality || 'In-Person'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Date & Time:</span>
                  <span className="font-mono text-slate-800">{formatDate(order.closingSession?.scheduledDate)} · {order.closingSession?.scheduledTime}</span>
                </div>
                <div>
                  <span className="text-slate-400 block">Location / Platform:</span>
                  <span className="text-slate-800 font-medium">{order.closingSession?.locationOrPlatform}</span>
                </div>
                <div>
                  <span className="text-slate-400 block">Notary / Signing Agent:</span>
                  <span className="text-slate-800">{order.closingSession?.notaryName}</span>
                </div>
              </div>

              <button
                onClick={() => onNavigateTab('closing')}
                className="w-full mt-4 py-2 px-3 text-xs font-medium text-indigo-700 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 rounded-lg transition-colors flex items-center justify-center gap-1.5"
              >
                <span>Launch Closing Room</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* SECTION 2: Title Requirements & Clearance Checklist */}
      {activeSection === 'requirements' && (
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-slate-900">Schedule B-I: Title Commitment Requirements</h3>
              <p className="text-xs text-slate-500 mt-0.5">
                All mandatory legal requirements that must be satisfied prior to issuing policy and disbursing funds.
              </p>
            </div>
            <button
              onClick={() => setShowAddReqModal(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Requirement</span>
            </button>
          </div>

          <div className="space-y-3">
            {order.titleRequirements.map((req) => (
              <div
                key={req.id}
                className={`p-4 rounded-xl border transition-all ${
                  req.status === 'Satisfied'
                    ? 'bg-emerald-50/50 border-emerald-200'
                    : req.status === 'Waived'
                    ? 'bg-slate-50 border-slate-200 opacity-75'
                    : 'bg-white border-amber-200 shadow-xs'
                }`}
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs font-bold text-slate-800">{req.code}</span>
                      <span className="text-xs text-slate-400">·</span>
                      <span className="text-xs font-semibold text-slate-700 px-2 py-0.5 rounded bg-white border border-slate-200">
                        {req.category}
                      </span>
                      {req.satisfiedAt && (
                        <span className="text-[11px] text-emerald-700 font-medium">
                          Satisfied on {formatDate(req.satisfiedAt)}
                        </span>
                      )}
                    </div>
                    <p className="text-sm font-medium text-slate-800 leading-normal">{req.description}</p>
                    {req.notes && (
                      <p className="text-xs text-slate-500 italic mt-1 bg-white/80 p-1.5 rounded border border-slate-200">
                        Note: {req.notes}
                      </p>
                    )}
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={() => toggleRequirementStatus(req.id)}
                      className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors flex items-center gap-1.5 ${
                        req.status === 'Satisfied'
                          ? 'bg-emerald-600 text-white border-emerald-600 hover:bg-emerald-700'
                          : req.status === 'Waived'
                          ? 'bg-slate-200 text-slate-700 border-slate-300 hover:bg-slate-300'
                          : 'bg-amber-100 text-amber-900 border-amber-300 hover:bg-amber-200'
                      }`}
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>{req.status}</span>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Add Requirement Modal */}
          {showAddReqModal && (
            <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center z-50 p-4">
              <div className="bg-white p-6 rounded-xl border border-slate-200 max-w-lg w-full shadow-xl">
                <h4 className="text-base font-bold text-slate-900 mb-3">Add Title Commitment Requirement</h4>
                <form onSubmit={handleAddRequirement} className="space-y-4">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs font-medium text-slate-700 block mb-1">Requirement Code</label>
                      <input
                        type="text"
                        placeholder="REQ-06"
                        value={newReqCode}
                        onChange={(e) => setNewReqCode(e.target.value)}
                        className="w-full text-xs p-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900"
                      />
                    </div>
                    <div>
                      <label className="text-xs font-medium text-slate-700 block mb-1">Category</label>
                      <select
                        value={newReqCategory}
                        onChange={(e) => setNewReqCategory(e.target.value as TitleRequirement['category'])}
                        className="w-full text-xs p-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900"
                      >
                        <option value="Lien / Mortgage">Lien / Mortgage</option>
                        <option value="Taxes">Taxes</option>
                        <option value="Legal / Authority">Legal / Authority</option>
                        <option value="Affidavit">Affidavit</option>
                        <option value="Survey">Survey</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="text-xs font-medium text-slate-700 block mb-1">Requirement Text</label>
                    <textarea
                      rows={3}
                      placeholder="e.g. Obtain recorded release of lien or satisfaction certificate..."
                      value={newReqDesc}
                      onChange={(e) => setNewReqDesc(e.target.value)}
                      className="w-full text-xs p-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900"
                      required
                    />
                  </div>

                  <div className="flex justify-end gap-2 pt-2">
                    <button
                      type="button"
                      onClick={() => setShowAddReqModal(false)}
                      className="px-3 py-1.5 text-xs font-medium text-slate-600 hover:text-slate-900"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-4 py-1.5 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg"
                    >
                      Save Requirement
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}
        </div>
      )}

      {/* SECTION 3: Parties & Contacts */}
      {activeSection === 'parties' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {order.parties.map((party) => (
            <div key={party.id} className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                    {party.role}
                  </span>
                  <User className="w-4 h-4 text-slate-400" />
                </div>
                <h4 className="text-sm font-bold text-slate-900 mt-2">{party.name}</h4>
                {party.company && <p className="text-xs text-slate-600 font-medium">{party.company}</p>}
                
                <div className="mt-3 space-y-1 text-xs text-slate-600">
                  <p className="flex items-center gap-1.5">
                    <span className="text-slate-400">Email:</span>
                    <a href={`mailto:${party.email}`} className="text-emerald-700 hover:underline">{party.email}</a>
                  </p>
                  <p className="flex items-center gap-1.5">
                    <span className="text-slate-400">Phone:</span>
                    <span className="font-mono text-slate-800">{party.phone}</span>
                  </p>
                  {party.address && (
                    <p className="text-[11px] text-slate-500 mt-1">{party.address}</p>
                  )}
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-end">
                <span className="text-[11px] text-slate-400">Verified Contact</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* SECTION 4: File Audit Notes */}
      {activeSection === 'notes' && (
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-6">
          <div>
            <h3 className="text-base font-bold text-slate-900">File Chronology & Settlement Notes</h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Time-stamped audit trail for title clearance, lender communications, and settlement events.
            </p>
          </div>

          <form onSubmit={handleAddNote} className="flex gap-2">
            <input
              type="text"
              placeholder="Add settlement log note (e.g. Spoke with loan officer, wire confirmed...)"
              value={newNoteText}
              onChange={(e) => setNewNoteText(e.target.value)}
              className="flex-1 text-xs p-2.5 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900"
            />
            <button
              type="submit"
              className="px-4 py-2 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg flex items-center gap-1.5 shrink-0"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Add Note</span>
            </button>
          </form>

          <div className="space-y-3 pt-2">
            {order.internalNotes.map((note, idx) => (
              <div key={idx} className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs flex items-start gap-3">
                <MessageSquare className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
                <p className="text-slate-800 leading-relaxed font-mono">{note}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
