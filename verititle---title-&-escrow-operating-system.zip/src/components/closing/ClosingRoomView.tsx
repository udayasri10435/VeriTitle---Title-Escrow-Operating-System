import React, { useState, useRef } from 'react';
import { 
  PenTool, 
  CheckCircle2, 
  Clock, 
  Calendar, 
  MapPin, 
  UserCheck, 
  ShieldCheck, 
  FileText, 
  Video, 
  Award, 
  X,
  FileCheck2,
  AlertCircle
} from 'lucide-react';
import { Order, ClosingDocument } from '../../types/titleEscrow';
import { formatDate } from '../../utils/formatters';

interface ClosingRoomViewProps {
  order: Order;
  onUpdateOrder: (updatedOrder: Order) => void;
  onNavigateTab: (tab: string) => void;
}

export const ClosingRoomView: React.FC<ClosingRoomViewProps> = ({
  order,
  onUpdateOrder,
  onNavigateTab,
}) => {
  const [activeSigningDoc, setActiveSigningDoc] = useState<ClosingDocument | null>(null);
  const [selectedSigner, setSelectedSigner] = useState<'Buyer' | 'Seller' | 'Notary' | 'Settlement Agent'>('Buyer');
  const [typedSignature, setTypedSignature] = useState('');
  const [signatureMode, setSignatureMode] = useState<'draw' | 'type'>('type');
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isDrawing, setIsDrawing] = useState(false);

  const session = order.closingSession;
  const buyer = order.parties.find((p) => p.role === 'Buyer' || p.role === 'Borrower')?.name || 'Buyer';
  const seller = order.parties.find((p) => p.role === 'Seller')?.name || 'Seller';

  // Check how many documents are fully signed
  const totalDocs = order.documents.length;
  const fullySignedDocs = order.documents.filter((d) => 
    d.requiredSigners.every((req) => d.signaturesCollected.includes(req))
  ).length;

  const isReadyToExecute = fullySignedDocs === totalDocs && totalDocs > 0;

  // Open signature modal
  const handleOpenSignModal = (doc: ClosingDocument, signerRole: 'Buyer' | 'Seller' | 'Notary' | 'Settlement Agent') => {
    setActiveSigningDoc(doc);
    setSelectedSigner(signerRole);
    setTypedSignature(
      signerRole === 'Buyer'
        ? buyer
        : signerRole === 'Seller'
        ? seller
        : signerRole === 'Notary'
        ? session.notaryName
        : 'Katherine Reed'
    );
  };

  // Canvas drawing handlers
  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement>) => {
    setIsDrawing(true);
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const rect = canvas.getBoundingClientRect();
    ctx.beginPath();
    ctx.moveTo(e.clientX - rect.left, e.clientY - rect.top);
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const rect = canvas.getBoundingClientRect();
    ctx.lineTo(e.clientX - rect.left, e.clientY - rect.top);
    ctx.strokeStyle = '#0F172A';
    ctx.lineWidth = 2.5;
    ctx.lineCap = 'round';
    ctx.stroke();
  };

  const stopDrawing = () => {
    setIsDrawing(false);
  };

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
    }
  };

  // Save Signature
  const handleConfirmSignature = () => {
    if (!activeSigningDoc) return;

    const updatedDocs = order.documents.map((doc) => {
      if (doc.id === activeSigningDoc.id) {
        const nextSignatures = Array.from(new Set([...doc.signaturesCollected, selectedSigner]));
        const isAllSigned = doc.requiredSigners.every((r) => nextSignatures.includes(r));
        return {
          ...doc,
          signaturesCollected: nextSignatures,
          status: isAllSigned ? ('Signed & Notarized' as const) : ('Out for Signature' as const),
          lastModified: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };
      }
      return doc;
    });

    const updatedNotes = [
      `${new Date().toISOString().split('T')[0]}: ${selectedSigner} executed ${activeSigningDoc.title} via digital settlement terminal.`,
      ...order.internalNotes,
    ];

    onUpdateOrder({
      ...order,
      documents: updatedDocs,
      internalNotes: updatedNotes,
    });

    setActiveSigningDoc(null);
  };

  // Execute closing
  const handleExecuteClosing = () => {
    const updated = {
      ...order,
      status: 'Closed & Executed' as const,
      closingSession: {
        ...order.closingSession,
        status: 'Completed' as const,
      },
      internalNotes: [
        `${new Date().toISOString().split('T')[0]}: Closing ceremony executed. All ${order.documents.length} legal documents signed and notarized. File is Clear to Disburse!`,
        ...order.internalNotes,
      ],
    };
    onUpdateOrder(updated);
  };

  return (
    <div className="space-y-6">
      {/* Session Overview Card */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-indigo-700 bg-indigo-50 border border-indigo-200 px-2.5 py-0.5 rounded">
                {session?.modality || 'In-Person Settlement'}
              </span>
              <span className={`text-xs font-mono font-medium px-2 py-0.5 rounded ${
                session?.status === 'Completed' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
              }`}>
                {session?.status || 'Scheduled'}
              </span>
            </div>

            <h2 className="text-xl font-bold text-slate-900 mt-2">
              Closing & Execution Session · File {order.fileNumber}
            </h2>
            <p className="text-xs text-slate-600 mt-1 flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-slate-400" />
              {session?.locationOrPlatform}
            </p>
          </div>

          {/* Quick Metrics & Execution Action */}
          <div className="flex items-center gap-4">
            <div className="text-right">
              <span className="text-xs text-slate-400 block">Signatures Progress</span>
              <span className="text-lg font-bold font-mono text-slate-900">
                {fullySignedDocs} / {totalDocs} Complete
              </span>
            </div>

            {order.status === 'Closed & Executed' || order.status === 'Disbursed & Recorded' ? (
              <div className="flex items-center gap-2 px-4 py-2 bg-emerald-50 text-emerald-800 border border-emerald-300 rounded-lg text-xs font-semibold">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Closing Executed</span>
              </div>
            ) : (
              <button
                onClick={handleExecuteClosing}
                disabled={!isReadyToExecute}
                className={`inline-flex items-center gap-2 px-4 py-2.5 text-xs font-semibold rounded-lg shadow-sm transition-all ${
                  isReadyToExecute
                    ? 'bg-emerald-600 hover:bg-emerald-500 text-white cursor-pointer'
                    : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                }`}
              >
                <Award className="w-4 h-4" />
                <span>Execute & Complete Closing</span>
              </button>
            )}
          </div>
        </div>

        {/* Notary & Signer Verification Row */}
        <div className="mt-5 pt-4 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
            <span className="text-slate-400 block font-medium">Assigned Notary Public</span>
            <span className="text-slate-900 font-semibold mt-0.5 block">{session?.notaryName}</span>
            <span className="text-slate-500 font-mono text-[11px]">Commission: {session?.notaryCommissionNumber}</span>
          </div>

          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
            <span className="text-slate-400 block font-medium">Date & Time</span>
            <span className="text-slate-900 font-semibold mt-0.5 block">{formatDate(session?.scheduledDate)}</span>
            <span className="text-slate-500 font-mono text-[11px]">{session?.scheduledTime}</span>
          </div>

          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
            <span className="text-slate-400 block font-medium">Signer Identity Check</span>
            <span className="text-emerald-700 font-semibold mt-0.5 flex items-center gap-1">
              <UserCheck className="w-3.5 h-3.5" />
              Government Photo ID Verified
            </span>
            <span className="text-slate-500 text-[11px]">Driver Licenses Recorded in Closing Log</span>
          </div>
        </div>
      </div>

      {/* Document Signing Checklist */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-slate-900">Closing Document Signing Package</h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Click "Sign" under any role to simulate electronic or wet signature capture.
            </p>
          </div>
          <button
            onClick={() => onNavigateTab('disbursement')}
            className="text-xs text-emerald-700 hover:text-emerald-900 font-medium flex items-center gap-1"
          >
            <span>Proceed to Escrow Disbursement Ledger</span>
            <span>&rarr;</span>
          </button>
        </div>

        <div className="divide-y divide-slate-200 border border-slate-200 rounded-xl overflow-hidden">
          {order.documents.map((doc) => {
            const isAllSigned = doc.requiredSigners.every((r) => doc.signaturesCollected.includes(r));

            return (
              <div key={doc.id} className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-slate-50 transition-colors">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-sm text-slate-900">{doc.title}</span>
                    <span className="text-xs text-slate-400">·</span>
                    <span className="text-[11px] text-slate-500 font-mono">{doc.totalPages} pages</span>
                    <span className={`text-[10px] font-semibold px-2 py-0.5 rounded ${
                      isAllSigned ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                    }`}>
                      {isAllSigned ? 'Executed' : doc.status}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500">
                    Category: {doc.category} · Last modified: {doc.lastModified}
                  </p>
                </div>

                {/* Signer Badges & Action Buttons */}
                <div className="flex items-center gap-2 flex-wrap">
                  {doc.requiredSigners.map((role) => {
                    const hasSigned = doc.signaturesCollected.includes(role);

                    return (
                      <div key={role} className="flex items-center gap-1">
                        {hasSigned ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-emerald-50 text-emerald-800 border border-emerald-300 text-xs font-medium">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                            {role}
                          </span>
                        ) : (
                          <button
                            onClick={() => handleOpenSignModal(doc, role)}
                            className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300 text-xs font-medium transition-colors"
                          >
                            <PenTool className="w-3 h-3 text-indigo-600" />
                            <span>Sign ({role})</span>
                          </button>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Interactive E-Signature Modal */}
      {activeSigningDoc && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl border border-slate-200 max-w-lg w-full p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div>
                <h4 className="text-sm font-bold text-slate-900">Sign Document</h4>
                <p className="text-xs text-slate-500">{activeSigningDoc.title}</p>
              </div>
              <button onClick={() => setActiveSigningDoc(null)} className="text-slate-400 hover:text-slate-700">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="mt-4 space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-700">
                  Signing As: <strong className="text-indigo-700 font-mono">{selectedSigner}</strong>
                </span>

                <div className="flex bg-slate-100 p-0.5 rounded-lg border border-slate-200 text-xs">
                  <button
                    onClick={() => setSignatureMode('type')}
                    className={`px-2.5 py-1 rounded-md transition-colors ${
                      signatureMode === 'type' ? 'bg-white text-slate-900 font-medium shadow-xs' : 'text-slate-600'
                    }`}
                  >
                    Type
                  </button>
                  <button
                    onClick={() => setSignatureMode('draw')}
                    className={`px-2.5 py-1 rounded-md transition-colors ${
                      signatureMode === 'draw' ? 'bg-white text-slate-900 font-medium shadow-xs' : 'text-slate-600'
                    }`}
                  >
                    Draw
                  </button>
                </div>
              </div>

              {signatureMode === 'type' ? (
                <div>
                  <label className="text-xs font-medium text-slate-600 block mb-1">Adopt Legal Name</label>
                  <input
                    type="text"
                    value={typedSignature}
                    onChange={(e) => setTypedSignature(e.target.value)}
                    className="w-full text-sm p-2.5 bg-slate-50 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-600 font-serif italic text-xl text-slate-900"
                  />
                  <p className="text-[11px] text-slate-400 mt-1">
                    Certified digital font signature verified under UETA & ESIGN Act.
                  </p>
                </div>
              ) : (
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <label className="text-xs font-medium text-slate-600">Draw with Mouse / Stylus</label>
                    <button
                      type="button"
                      onClick={clearCanvas}
                      className="text-[11px] text-slate-500 hover:text-slate-900"
                    >
                      Clear
                    </button>
                  </div>
                  <canvas
                    ref={canvasRef}
                    width={440}
                    height={120}
                    onMouseDown={startDrawing}
                    onMouseMove={draw}
                    onMouseUp={stopDrawing}
                    onMouseLeave={stopDrawing}
                    className="w-full h-28 bg-slate-50 border border-slate-300 rounded-lg cursor-crosshair touch-none"
                  />
                </div>
              )}

              {/* Legal Acknowledgment */}
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-[11px] text-slate-600 leading-relaxed">
                By clicking "Apply Legal Signature", I certify that I am authorized to execute this real estate closing instrument and intend this to be my legal signature.
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setActiveSigningDoc(null)}
                  className="px-3 py-1.5 text-xs font-medium text-slate-600 hover:text-slate-900"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleConfirmSignature}
                  className="px-4 py-2 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg shadow-sm"
                >
                  Apply Legal Signature
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
