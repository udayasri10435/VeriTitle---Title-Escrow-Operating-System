import React, { useState } from 'react';
import { 
  ShieldCheck, 
  CheckCircle2, 
  AlertCircle, 
  Printer, 
  FileCheck, 
  Lock, 
  Layers, 
  DollarSign, 
  BookOpen,
  Award
} from 'lucide-react';

interface PillarItem {
  id: string;
  pillar: number;
  title: string;
  requirement: string;
  compliant: boolean;
  notes: string;
}

export const AltaComplianceView: React.FC = () => {
  const [pillars, setPillars] = useState<PillarItem[]>([
    {
      id: 'p1',
      pillar: 1,
      title: 'Licensing & Good Standing',
      requirement: 'Establish and maintain current state title insurance agency licenses, underwriter appointment agreements, and corporate registration in good standing.',
      compliant: true,
      notes: 'TX Department of Insurance Title Agency License #291042 verified active through 2028.',
    },
    {
      id: 'p2-1',
      pillar: 2,
      title: 'Escrow Trust Accounting - Segregation of Funds',
      requirement: 'Maintain separate bank accounts for escrow trust funds and operating funds with appropriate trial balances.',
      compliant: true,
      notes: 'Segregated IOLTA / Escrow Trust Account at JPMorgan Chase Bank.',
    },
    {
      id: 'p2-2',
      pillar: 2,
      title: 'Escrow Trust Accounting - Three-Way Reconciliation',
      requirement: 'Perform daily book-to-bank and monthly three-way reconciliation (Bank Balance, Book Balance, Escrow File Balances).',
      compliant: true,
      notes: 'Monthly three-way reconciliation completed and reviewed by internal CPA.',
    },
    {
      id: 'p2-3',
      pillar: 2,
      title: 'Positive Pay & Dual Wire Authorization',
      requirement: 'Implement Positive Pay anti-fraud controls and dual-signoff authorization on all outgoing escrow wire transfers.',
      compliant: true,
      notes: 'Automated Positive Pay transmission enabled. Dual-approver rule enforced.',
    },
    {
      id: 'p3-1',
      pillar: 3,
      title: 'Privacy & Information Security (NPI Protection)',
      requirement: 'Adopt a written Information Security Program to protect Non-public Personal Information (NPI) under the Gramm-Leach-Bliley Act.',
      compliant: true,
      notes: 'AES-256 encrypted database, clean desk policy, secure shredding containers.',
    },
    {
      id: 'p3-2',
      pillar: 3,
      title: 'Wire Fraud Prevention & Two-Factor Verification',
      requirement: 'Enforce mandatory independent verbal telephone callbacks using known good phone numbers prior to wiring any closing proceeds.',
      compliant: true,
      notes: 'VeriTitle Wire Verification Shield active on all outgoing wire releases.',
    },
    {
      id: 'p4',
      pillar: 4,
      title: 'Recording Procedures & Settlement Pricing',
      requirement: 'Submit legal instruments (Deeds, Mortgages) for recording within two business days of settlement and maintain published rate manuals.',
      compliant: true,
      notes: 'Integrated Simplifile e-recording workflow with county recording tracking.',
    },
    {
      id: 'p5',
      pillar: 5,
      title: 'Title Policy Production & Delivery',
      requirement: 'Issue and deliver final title insurance policies to owners and lenders within thirty (30) days of closing.',
      compliant: true,
      notes: 'Average policy issuance turnaround: 14 calendar days.',
    },
    {
      id: 'p6',
      pillar: 6,
      title: 'Errors & Omissions (E&O) & Fidelity Insurance',
      requirement: 'Maintain Errors and Omissions insurance and Crime / Employee Dishonesty coverage meeting statutory and lender minimums.',
      compliant: true,
      notes: '$2,000,000 E&O Policy #EO-991204 with Travelers Casualty; Fidelity Bond active.',
    },
    {
      id: 'p7',
      pillar: 7,
      title: 'Consumer Complaints & Dispute Resolution',
      requirement: 'Maintain written procedures for intake, logging, investigation, and timely response to consumer inquiries and complaints.',
      compliant: true,
      notes: 'Consumer complaint log reviewed quarterly by Managing Counsel.',
    },
  ]);

  const togglePillar = (id: string) => {
    setPillars((prev) =>
      prev.map((item) => (item.id === id ? { ...item, compliant: !item.compliant } : item))
    );
  };

  const totalItems = pillars.length;
  const compliantCount = pillars.filter((p) => p.compliant).length;
  const compliancePercentage = Math.round((compliantCount / totalItems) * 100);

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-blue-700 bg-blue-50 border border-blue-200 px-2.5 py-0.5 rounded">
                ALTA Best Practices Framework
              </span>
              <span className="text-xs text-slate-400">·</span>
              <span className="text-xs text-slate-500 font-medium">Title Insurance & Settlement Agency Audit</span>
            </div>
            <h2 className="text-xl font-bold text-slate-900 mt-2">
              Title Agency ALTA 7 Pillars Compliance
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Comprehensive regulatory audit controls for title agencies and real estate settlement law firms.
            </p>
          </div>

          <div className="flex items-center gap-4">
            <div className="text-right">
              <span className="text-xs text-slate-400 block font-medium">Compliance Index</span>
              <span className="text-2xl font-bold font-mono text-slate-900 tabular-nums">
                {compliancePercentage}%
              </span>
            </div>

            <button
              onClick={() => window.print()}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-lg no-print"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Audit Sheet</span>
            </button>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="mt-4">
          <div className="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden">
            <div
              className={`h-2.5 rounded-full transition-all duration-500 ${
                compliancePercentage === 100 ? 'bg-emerald-600' : 'bg-blue-600'
              }`}
              style={{ width: `${compliancePercentage}%` }}
            />
          </div>
          <div className="flex justify-between items-center text-[11px] text-slate-400 mt-1">
            <span>{compliantCount} of {totalItems} controls certified</span>
            <span>Target: 100% Certified for Lender Approval</span>
          </div>
        </div>
      </div>

      {/* Pillars Checklist */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-4">
        <h3 className="text-sm font-bold text-slate-900">Pillar Requirements Audit</h3>

        <div className="space-y-3">
          {pillars.map((item) => (
            <div
              key={item.id}
              className={`p-4 rounded-xl border transition-all ${
                item.compliant
                  ? 'bg-slate-50/70 border-slate-200'
                  : 'bg-amber-50/70 border-amber-300'
              }`}
            >
              <div className="flex items-start justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold font-mono text-slate-800">Pillar {item.pillar}</span>
                    <span className="text-xs text-slate-400">·</span>
                    <span className="text-xs font-semibold text-slate-900">{item.title}</span>
                  </div>
                  <p className="text-xs text-slate-600 leading-normal">{item.requirement}</p>
                  <p className="text-[11px] text-slate-500 font-mono mt-1 bg-white p-2 rounded border border-slate-200">
                    Evidence: {item.notes}
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => togglePillar(item.id)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-colors flex items-center gap-1.5 shrink-0 no-print ${
                    item.compliant
                      ? 'bg-emerald-600 text-white border-emerald-600 hover:bg-emerald-700'
                      : 'bg-amber-100 text-amber-900 border-amber-300 hover:bg-amber-200'
                  }`}
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>{item.compliant ? 'Certified' : 'Review Needed'}</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
