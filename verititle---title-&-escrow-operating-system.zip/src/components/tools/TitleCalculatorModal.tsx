import React, { useState } from 'react';
import { X, Calculator, ArrowRight, Check, DollarSign } from 'lucide-react';
import { Order } from '../../types/titleEscrow';
import { estimateTitlePremium, formatCurrency, recalculateAltaStatement } from '../../utils/formatters';

interface TitleCalculatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeOrder: Order | null;
  onUpdateOrder: (updatedOrder: Order) => void;
}

export const TitleCalculatorModal: React.FC<TitleCalculatorModalProps> = ({
  isOpen,
  onClose,
  activeOrder,
  onUpdateOrder,
}) => {
  const [purchasePrice, setPurchasePrice] = useState<number>(activeOrder?.purchasePrice || 500000);
  const [loanAmount, setLoanAmount] = useState<number>(activeOrder?.loanAmount || 400000);
  const [isRefi, setIsRefi] = useState<boolean>(activeOrder?.type === 'Residential Refinance');
  const [selectedState, setSelectedState] = useState<string>(activeOrder?.property.state || 'TX');
  const [copiedSuccess, setCopiedSuccess] = useState(false);

  if (!isOpen) return null;

  const calculation = estimateTitlePremium(purchasePrice, loanAmount, isRefi);

  // Transfer tax rough estimation based on state
  const transferTaxRate = selectedState === 'PA' ? 0.02 : selectedState === 'FL' ? 0.007 : selectedState === 'NY' ? 0.014 : 0;
  const estimatedTransferTax = Math.round(purchasePrice * transferTaxRate);

  const grandTotal = calculation.totalTitleCharges + estimatedTransferTax;

  const handleApplyToOrder = () => {
    if (!activeOrder) return;

    // Filter out previous title charge line items and inject recalculated items
    const filteredItems = activeOrder.altaStatement.lineItems.filter((i) => i.section !== '500_TitleCharges');

    const newTitleItems = [
      ...(!isRefi
        ? [
            {
              id: `li-calc-${Date.now()}-1`,
              section: '500_TitleCharges' as const,
              lineCode: '501',
              description: `Owner's Title Insurance Policy (${activeOrder.underwriter})`,
              payeeOrPayor: activeOrder.underwriter,
              sellerDebit: calculation.ownersPremium,
            },
          ]
        : []),
      ...(loanAmount > 0
        ? [
            {
              id: `li-calc-${Date.now()}-2`,
              section: '500_TitleCharges' as const,
              lineCode: '502',
              description: `Loan Title Insurance Policy (${isRefi ? 'Refinance Rate' : 'Simultaneous Issue Rate'})`,
              payeeOrPayor: activeOrder.underwriter,
              borrowerDebit: calculation.lendersPremium,
            },
          ]
        : []),
      {
        id: `li-calc-${Date.now()}-3`,
        section: '500_TitleCharges' as const,
        lineCode: '503',
        description: 'Title Examination & Abstract Search Fee',
        payeeOrPayor: 'VeriTitle Settlement Services',
        borrowerDebit: calculation.titleSearchFee,
      },
      {
        id: `li-calc-${Date.now()}-4`,
        section: '500_TitleCharges' as const,
        lineCode: '504',
        description: 'Settlement & Escrow Closing Fee (Split 50/50)',
        payeeOrPayor: 'VeriTitle Settlement Services',
        borrowerDebit: Math.round(calculation.settlementClosingFee / 2),
        sellerDebit: Math.round(calculation.settlementClosingFee / 2),
      },
      {
        id: `li-calc-${Date.now()}-5`,
        section: '500_TitleCharges' as const,
        lineCode: '505',
        description: 'Courier & Wire Verification Security Fee',
        payeeOrPayor: 'VeriTitle Settlement Services',
        borrowerDebit: Math.round(calculation.courierAndWireFee / 2),
        sellerDebit: Math.round(calculation.courierAndWireFee / 2),
      },
    ];

    const updatedStatement = recalculateAltaStatement({
      ...activeOrder.altaStatement,
      lineItems: [...filteredItems, ...newTitleItems],
    });

    onUpdateOrder({
      ...activeOrder,
      altaStatement: updatedStatement,
      internalNotes: [
        `${new Date().toISOString().split('T')[0]}: Recalculated title insurance premiums applied to ALTA Statement.`,
        ...activeOrder.internalNotes,
      ],
    });

    setCopiedSuccess(true);
    setTimeout(() => {
      setCopiedSuccess(false);
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl border border-slate-200 max-w-xl w-full p-6 shadow-2xl space-y-6">
        <div className="flex items-center justify-between pb-3 border-b border-slate-200">
          <div className="flex items-center gap-2">
            <Calculator className="w-5 h-5 text-emerald-600" />
            <h3 className="text-base font-bold text-slate-900">
              Title Insurance & Settlement Fee Calculator
            </h3>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-700">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Input Parameters */}
        <div className="grid grid-cols-2 gap-4 text-xs">
          <div>
            <label className="text-slate-600 font-medium block mb-1">State Jurisdiction</label>
            <select
              value={selectedState}
              onChange={(e) => setSelectedState(e.target.value)}
              className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg"
            >
              <option value="TX">Texas (Promulgated TDI Rates)</option>
              <option value="CA">California (Filed Underwriter Rates)</option>
              <option value="FL">Florida (Promulgated Rate Schedule)</option>
              <option value="OH">Ohio (TIRBO Rate Manual)</option>
              <option value="PA">Pennsylvania (TIRBOP Rates)</option>
              <option value="NY">New York (TIRSA Rates)</option>
            </select>
          </div>

          <div>
            <label className="text-slate-600 font-medium block mb-1">Transaction Type</label>
            <select
              value={isRefi ? 'refi' : 'purchase'}
              onChange={(e) => setIsRefi(e.target.value === 'refi')}
              className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg"
            >
              <option value="purchase">Purchase (Owner + Lender Policy)</option>
              <option value="refi">Refinance (Loan Policy Only)</option>
            </select>
          </div>

          {!isRefi && (
            <div>
              <label className="text-slate-600 font-medium block mb-1">Purchase Price ($)</label>
              <input
                type="number"
                value={purchasePrice}
                onChange={(e) => setPurchasePrice(Number(e.target.value))}
                className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg font-mono"
              />
            </div>
          )}

          <div>
            <label className="text-slate-600 font-medium block mb-1">Loan Amount ($)</label>
            <input
              type="number"
              value={loanAmount}
              onChange={(e) => setLoanAmount(Number(e.target.value))}
              className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg font-mono"
            />
          </div>
        </div>

        {/* Calculated Breakdown */}
        <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 text-xs space-y-2">
          <span className="font-bold text-slate-800 uppercase tracking-wider text-[11px] block mb-2">
            Estimated Fee Schedule Breakdown
          </span>

          {!isRefi && (
            <div className="flex justify-between">
              <span className="text-slate-600">Owner's Title Insurance Policy:</span>
              <span className="font-mono font-semibold text-slate-900">{formatCurrency(calculation.ownersPremium)}</span>
            </div>
          )}

          {loanAmount > 0 && (
            <div className="flex justify-between">
              <span className="text-slate-600">
                Lender's Title Policy {isRefi ? '(Refi Rate)' : '(Simultaneous Issue)'}:
              </span>
              <span className="font-mono font-semibold text-slate-900">{formatCurrency(calculation.lendersPremium)}</span>
            </div>
          )}

          <div className="flex justify-between">
            <span className="text-slate-600">Title Search & Examination:</span>
            <span className="font-mono text-slate-900">{formatCurrency(calculation.titleSearchFee)}</span>
          </div>

          <div className="flex justify-between">
            <span className="text-slate-600">Settlement & Closing Escrow Fee:</span>
            <span className="font-mono text-slate-900">{formatCurrency(calculation.settlementClosingFee)}</span>
          </div>

          <div className="flex justify-between">
            <span className="text-slate-600">Courier & Secure Wire Verification:</span>
            <span className="font-mono text-slate-900">{formatCurrency(calculation.courierAndWireFee)}</span>
          </div>

          {estimatedTransferTax > 0 && (
            <div className="flex justify-between border-t border-slate-200 pt-1">
              <span className="text-slate-600">Estimated State/County Transfer Tax ({selectedState}):</span>
              <span className="font-mono text-slate-900">{formatCurrency(estimatedTransferTax)}</span>
            </div>
          )}

          <div className="border-t-2 border-slate-300 pt-2 flex justify-between text-sm font-bold">
            <span className="text-slate-900">Total Title & Settlement Estimate:</span>
            <span className="font-mono text-emerald-700">{formatCurrency(grandTotal)}</span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-between pt-2">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-600 hover:text-slate-900"
          >
            Close
          </button>

          {activeOrder && (
            <button
              type="button"
              onClick={handleApplyToOrder}
              disabled={copiedSuccess}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-lg shadow-sm"
            >
              {copiedSuccess ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Applied to ALTA Statement!</span>
                </>
              ) : (
                <>
                  <span>Apply to File {activeOrder.fileNumber} ALTA Statement</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </>
              )}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
