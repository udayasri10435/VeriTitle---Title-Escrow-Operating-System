import React, { useState } from 'react';
import { 
  FileSpreadsheet, 
  FileText, 
  Scroll, 
  ShieldAlert, 
  Printer, 
  CheckCircle2, 
  Download,
  Stamp,
  ExternalLink,
  Lock
} from 'lucide-react';
import { Order } from '../../types/titleEscrow';
import { AltaSettlementStatement } from './AltaSettlementStatement';
import { formatDate, formatCurrency } from '../../utils/formatters';

interface DocumentPrepViewProps {
  order: Order;
  onUpdateOrder: (updatedOrder: Order) => void;
  onNavigateTab: (tab: string) => void;
}

export const DocumentPrepView: React.FC<DocumentPrepViewProps> = ({
  order,
  onUpdateOrder,
  onNavigateTab,
}) => {
  const [activeDoc, setActiveDoc] = useState<'alta' | 'deed' | 'commitment' | 'affidavit' | 'wireNotice'>('alta');

  const buyer = order.parties.find((p) => p.role === 'Buyer' || p.role === 'Borrower')?.name || 'David R. Vance & Sarah M. Vance';
  const seller = order.parties.find((p) => p.role === 'Seller')?.name || 'Marcus E. Thornton';
  const lender = order.parties.find((p) => p.role === 'Lender')?.name || 'First Horizon Home Mortgage Corp.';

  return (
    <div className="space-y-6">
      {/* Top Document Category Navigation Tabs */}
      <div className="bg-white p-2 rounded-xl border border-slate-200 shadow-xs flex items-center gap-1 overflow-x-auto no-print">
        <button
          onClick={() => setActiveDoc('alta')}
          className={`flex items-center gap-2 px-3.5 py-2 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
            activeDoc === 'alta'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
          <span>ALTA Settlement Statement</span>
        </button>

        <button
          onClick={() => setActiveDoc('deed')}
          className={`flex items-center gap-2 px-3.5 py-2 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
            activeDoc === 'deed'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Scroll className="w-4 h-4 text-amber-500" />
          <span>General Warranty Deed</span>
        </button>

        <button
          onClick={() => setActiveDoc('commitment')}
          className={`flex items-center gap-2 px-3.5 py-2 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
            activeDoc === 'commitment'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Stamp className="w-4 h-4 text-blue-500" />
          <span>Title Commitment (Schedules A & B)</span>
        </button>

        <button
          onClick={() => setActiveDoc('affidavit')}
          className={`flex items-center gap-2 px-3.5 py-2 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
            activeDoc === 'affidavit'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <FileText className="w-4 h-4 text-purple-500" />
          <span>Owner Title Affidavit & FIRPTA</span>
        </button>

        <button
          onClick={() => setActiveDoc('wireNotice')}
          className={`flex items-center gap-2 px-3.5 py-2 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
            activeDoc === 'wireNotice'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <ShieldAlert className="w-4 h-4 text-red-500" />
          <span>Wire Fraud Notice & Verification</span>
        </button>
      </div>

      {/* DOCUMENT 1: ALTA Statement */}
      {activeDoc === 'alta' && (
        <AltaSettlementStatement order={order} onUpdateOrder={onUpdateOrder} />
      )}

      {/* DOCUMENT 2: General Warranty Deed */}
      {activeDoc === 'deed' && (
        <div className="bg-white border border-slate-300 rounded-xl shadow-md p-8 sm:p-12 print-sheet max-w-4xl mx-auto space-y-6">
          <div className="flex items-center justify-between border-b-2 border-slate-900 pb-4 no-print">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-widest">
              State of {order.property.state} · County of {order.property.county}
            </span>
            <button
              onClick={() => window.print()}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-lg"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Deed</span>
            </button>
          </div>

          {/* Deed Recording Header Block */}
          <div className="border border-slate-400 p-4 text-[11px] font-mono leading-tight bg-slate-50">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="font-bold">AFTER RECORDING RETURN TO:</p>
                <p>VeriTitle Settlement Services LLC</p>
                <p>Post-Closing Recording Dept.</p>
                <p>{order.property.address}</p>
                <p>{order.property.city}, {order.property.state} {order.property.zip}</p>
              </div>
              <div className="border-l border-slate-300 pl-4">
                <p className="font-bold">TAX PARCEL ID (APN):</p>
                <p>{order.property.parcelId}</p>
                <p className="mt-2 font-bold">ESCROW FILE #:</p>
                <p>{order.fileNumber}</p>
              </div>
            </div>
          </div>

          <div className="text-center pt-2">
            <h2 className="text-xl font-serif font-bold uppercase tracking-wider text-slate-900">
              General Warranty Deed
            </h2>
            <p className="text-xs text-slate-500 font-serif italic mt-1">
              With English Covenants of Title
            </p>
          </div>

          <div className="space-y-4 text-xs sm:text-sm font-serif leading-relaxed text-slate-800 text-justify">
            <p>
              <strong>NOTICE OF CONFIDENTIALITY RIGHTS:</strong> IF YOU ARE A NATURAL PERSON, YOU MAY REMOVE OR STRIKE ANY OR ALL OF THE FOLLOWING INFORMATION FROM ANY INSTRUMENT THAT TRANSFERS AN INTEREST IN REAL PROPERTY BEFORE IT IS FILED FOR RECORD IN THE PUBLIC RECORDS: YOUR SOCIAL SECURITY NUMBER OR YOUR DRIVER'S LICENSE NUMBER.
            </p>

            <p>
              <strong>DATE:</strong> The {new Date(order.targetClosingDate).getDate()}th day of{' '}
              {new Date(order.targetClosingDate).toLocaleString('default', { month: 'long' })}, {new Date(order.targetClosingDate).getFullYear()}.
            </p>

            <p>
              <strong>GRANTOR:</strong> {seller}, whose mailing address is {order.property.address}, {order.property.city}, {order.property.state} {order.property.zip}.
            </p>

            <p>
              <strong>GRANTEE:</strong> {buyer}, whose mailing address is {order.property.address}, {order.property.city}, {order.property.state} {order.property.zip}.
            </p>

            <p>
              <strong>CONSIDERATION:</strong> TEN AND NO/100 DOLLARS ($10.00) and other good and valuable consideration in hand paid by Grantee, the receipt and sufficiency of which are hereby acknowledged and confessed, and for which no lien, express or implied, is retained.
            </p>

            <p>
              <strong>PROPERTY (INCLUDING ANY IMPROVEMENTS):</strong>
            </p>

            <div className="p-3 bg-slate-50 border border-slate-300 rounded font-mono text-xs leading-normal">
              {order.property.legalDescription}
            </div>

            <p>
              <strong>RESERVATIONS FROM AND EXCEPTIONS TO CONVEYANCE AND WARRANTY:</strong> Easements, rights-of-way, and prescriptive rights, whether of record or not; all presently recorded restrictions, reservations, covenants, conditions, oil and gas leases, mineral severances, and other instruments, other than liens and conveyances, that affect the property; and taxes for the current year, the payment of which Grantee assumes.
            </p>

            <p>
              Grantor, for the consideration and subject to the reservations from and exceptions to conveyance and warranty, GRANTS, SELLS, AND CONVEYS to Grantee the property, together with all and singular the rights and appurtenances thereto in any wise belonging, to have and to hold to Grantee, Grantee's heirs, executors, administrators, successors, or assigns forever. Grantor hereby binds Grantor and Grantor's heirs, executors, administrators, and successors to WARRANT AND FOREVER DEFEND all and singular the property to Grantee and Grantee's heirs, executors, administrators, successors, and assigns, against every person whomsoever lawfully claiming or to claim the same or any part thereof, except as to the reservations from and exceptions to conveyance and warranty.
            </p>
          </div>

          {/* Execution Block */}
          <div className="pt-8">
            <div className="max-w-xs ml-auto border-t border-slate-900 pt-2 text-right">
              <span className="font-semibold text-sm block">{seller}</span>
              <span className="text-xs text-slate-500">Grantor Signature</span>
            </div>
          </div>

          {/* Notary Jurat */}
          <div className="border border-slate-300 p-4 rounded bg-slate-50 text-xs font-serif leading-relaxed mt-6">
            <p className="font-bold">STATE OF {order.property.state}, COUNTY OF {order.property.county} ss:</p>
            <p className="mt-2">
              Before me, the undersigned Notary Public in and for said State, on this day personally appeared{' '}
              <strong>{seller}</strong>, known to me (or satisfactorily proven) to be the person whose name is subscribed to the foregoing instrument, and acknowledged to me that they executed the same for the purposes and consideration therein expressed.
            </p>
            <p className="mt-2">
              Given under my hand and seal of office this _____ day of ________________, 20____.
            </p>
            <div className="mt-6 pt-4 border-t border-slate-300 flex justify-between items-center">
              <div>
                <p className="font-mono text-[11px] text-slate-600">[NOTARY PUBLIC SEAL]</p>
              </div>
              <div className="border-t border-slate-800 pt-1 text-right w-64">
                <p className="font-bold">Notary Public, State of {order.property.state}</p>
                <p className="text-[10px] text-slate-500">My Commission Expires: _________________</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* DOCUMENT 3: Title Insurance Commitment */}
      {activeDoc === 'commitment' && (
        <div className="bg-white border border-slate-300 rounded-xl shadow-md p-8 sm:p-12 print-sheet max-w-4xl mx-auto space-y-6">
          <div className="flex items-center justify-between border-b-2 border-slate-900 pb-4 no-print">
            <div className="flex items-center gap-2">
              <Stamp className="w-5 h-5 text-emerald-600" />
              <span className="text-sm font-bold text-slate-900 uppercase">
                ALTA Commitment for Title Insurance
              </span>
            </div>
            <button
              onClick={() => window.print()}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-lg"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Commitment</span>
            </button>
          </div>

          <div className="border border-slate-300 p-4 rounded-lg bg-slate-50 text-xs">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <span className="text-slate-400 block font-semibold">ISSUING UNDERWRITER:</span>
                <span className="font-bold text-slate-900 text-sm">{order.underwriter}</span>
                <span className="text-slate-600 block mt-1">Commitment #: {order.policyNumber}</span>
              </div>
              <div>
                <span className="text-slate-400 block font-semibold">ISSUING AGENT:</span>
                <span className="font-bold text-slate-900 text-sm">VeriTitle Settlement Services LLC</span>
                <span className="text-slate-600 block mt-1">Escrow File #: {order.fileNumber}</span>
              </div>
            </div>
          </div>

          {/* SCHEDULE A */}
          <div className="space-y-3">
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-900 border-b border-slate-200 pb-1">
              SCHEDULE A
            </h3>
            
            <div className="space-y-2 text-xs leading-relaxed text-slate-800">
              <p><strong>1. Effective Date:</strong> {formatDate(order.orderDate)} at 8:00 AM</p>
              <p><strong>2. Policy or Policies to be issued:</strong></p>
              <div className="ml-4 space-y-1">
                <p>
                  (a) <strong>ALTA Owner's Policy:</strong> Amount: {formatCurrency(order.purchasePrice)}
                  <br />Proposed Insured: {buyer}
                </p>
                {order.loanAmount > 0 && (
                  <p>
                    (b) <strong>ALTA Loan Policy:</strong> Amount: {formatCurrency(order.loanAmount)}
                    <br />Proposed Insured: {lender}, its successors and/or assigns
                  </p>
                )}
              </div>
              <p><strong>3. Title to the estate or interest is at the Effective Date vested in:</strong></p>
              <p className="ml-4 font-semibold">{seller}</p>
              <p><strong>4. The land referred to in this Commitment is described as follows:</strong></p>
              <div className="ml-4 p-2.5 bg-slate-50 border border-slate-200 rounded font-mono text-xs">
                {order.property.legalDescription}
              </div>
            </div>
          </div>

          {/* SCHEDULE B-I */}
          <div className="space-y-3 pt-4 border-t border-slate-200">
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-900 border-b border-slate-200 pb-1">
              SCHEDULE B - SECTION I: REQUIREMENTS
            </h3>
            <p className="text-xs text-slate-500">
              The following are the requirements to be complied with before the Company will issue its policy of title insurance:
            </p>
            <ol className="list-decimal pl-5 space-y-2 text-xs text-slate-800">
              {order.titleRequirements.map((req) => (
                <li key={req.id}>
                  <strong>{req.code} [{req.category}]:</strong> {req.description}
                  <span className={`ml-2 font-mono text-[10px] font-semibold px-1.5 py-0.2 rounded ${
                    req.status === 'Satisfied' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                  }`}>
                    {req.status}
                  </span>
                </li>
              ))}
            </ol>
          </div>

          {/* SCHEDULE B-II */}
          <div className="space-y-3 pt-4 border-t border-slate-200">
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-900 border-b border-slate-200 pb-1">
              SCHEDULE B - SECTION II: EXCEPTIONS
            </h3>
            <p className="text-xs text-slate-500">
              The policy will not insure against loss or damage arising from the following:
            </p>
            <ol className="list-decimal pl-5 space-y-2 text-xs text-slate-800">
              {order.titleExceptions.map((exc) => (
                <li key={exc.id}>
                  <strong>Item {exc.itemNumber} ({exc.type}):</strong> {exc.description}
                </li>
              ))}
            </ol>
          </div>
        </div>
      )}

      {/* DOCUMENT 4: Owner's Title Affidavit & FIRPTA */}
      {activeDoc === 'affidavit' && (
        <div className="bg-white border border-slate-300 rounded-xl shadow-md p-8 sm:p-12 print-sheet max-w-4xl mx-auto space-y-6 text-slate-800 font-serif text-xs sm:text-sm leading-relaxed">
          <div className="flex items-center justify-between border-b-2 border-slate-900 pb-4 no-print font-sans">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-widest">
              Standard ALTA Closing Affidavit
            </span>
            <button
              onClick={() => window.print()}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-lg"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Affidavit</span>
            </button>
          </div>

          <div className="text-center">
            <h2 className="text-xl font-bold uppercase tracking-wider text-slate-900">
              Owner's Title Affidavit & FIRPTA Certificate
            </h2>
            <p className="text-xs text-slate-500 italic mt-0.5">
              Certification of Non-Foreign Status & Mechanic's Lien Clearance
            </p>
          </div>

          <p>
            <strong>STATE OF {order.property.state}, COUNTY OF {order.property.county} ss:</strong>
          </p>

          <p>
            The undersigned, <strong>{seller}</strong> ("Affiant"), being first duly sworn according to law, deposes and states under oath as follows:
          </p>

          <ol className="list-decimal pl-5 space-y-2.5 text-justify">
            <li>
              Affiant is the fee simple owner of the real property situated at {order.property.address}, {order.property.city}, {order.property.state} (Tax Parcel ID: {order.property.parcelId}).
            </li>
            <li>
              <strong>NO MECHANIC'S LIENS:</strong> Within the past 120 days, no labor has been performed, and no materials or fixtures have been furnished for or about the property for which payment has not been made in full. No person or contractor has any right to file a mechanic's or materialman's lien against said property.
            </li>
            <li>
              <strong>POSSESSION & TITLE:</strong> Affiant is in open, peaceable, and undisturbed possession of the property. There are no adverse claims, unrecorded leases, easements, boundary disputes, or agreements affecting ownership of the property.
            </li>
            <li>
              <strong>JUDGMENTS & BANKRUPTCY:</strong> There are no unrecorded mortgages, attachments, judgments, tax liens, or bankruptcies filed or pending against Affiant in any state or federal court.
            </li>
            <li>
              <strong>SECTION 1445 NON-FOREIGN STATUS (FIRPTA):</strong> Section 1445 of the Internal Revenue Code provides that a transferee (Buyer) of a U.S. real property interest must withhold tax if the transferor is a foreign person. Affiant hereby certifies under penalties of perjury that Affiant is NOT a nonresident alien, foreign corporation, foreign partnership, foreign trust, or foreign estate as those terms are defined in the Internal Revenue Code and Income Tax Regulations.
            </li>
          </ol>

          <div className="pt-8">
            <div className="max-w-xs ml-auto border-t border-slate-900 pt-2 text-right">
              <span className="font-semibold block">{seller}</span>
              <span className="text-xs text-slate-500">Affiant / Seller Signature</span>
            </div>
          </div>

          <div className="border border-slate-300 p-4 rounded bg-slate-50 text-xs mt-6">
            <p>Subscribed and sworn to before me this _____ day of ________________, 20____.</p>
            <div className="mt-4 pt-2 border-t border-slate-300 flex justify-between items-center font-sans">
              <span className="text-slate-400 font-mono text-[11px]">[NOTARY SEAL]</span>
              <span className="text-slate-800 font-semibold">Notary Public, State of {order.property.state}</span>
            </div>
          </div>
        </div>
      )}

      {/* DOCUMENT 5: Wire Fraud Notice */}
      {activeDoc === 'wireNotice' && (
        <div className="bg-white border-2 border-red-200 rounded-xl shadow-md p-8 sm:p-12 print-sheet max-w-4xl mx-auto space-y-6">
          <div className="flex items-center justify-between border-b border-red-200 pb-4 no-print">
            <div className="flex items-center gap-2 text-red-600 font-bold">
              <ShieldAlert className="w-5 h-5" />
              <span className="text-sm uppercase tracking-wider">Critical ALTA Wire Fraud Alert</span>
            </div>
            <button
              onClick={() => window.print()}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-lg"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Notice</span>
            </button>
          </div>

          <div className="bg-red-50 border border-red-300 p-4 rounded-lg text-xs text-red-900 space-y-2">
            <h3 className="font-bold text-sm uppercase flex items-center gap-1.5">
              <Lock className="w-4 h-4 text-red-700" />
              Do Not Wire Funds Without Calling Our Office First!
            </h3>
            <p className="leading-relaxed">
              Cyber criminals are hacking email accounts of real estate agents, title companies, and lenders to send fake wiring instructions. 
              <strong> VeriTitle Settlement Services will NEVER email you changes to wiring instructions.</strong>
            </p>
          </div>

          <div className="space-y-4 text-xs sm:text-sm text-slate-800 leading-relaxed">
            <h4 className="font-bold text-slate-900">MANDATORY TWO-FACTOR TELEPHONE CALLBACK PROTOCOL:</h4>
            <p>
              Before sending any wire (earnest money or cash-to-close balance), you must call our verified telephone number below using a trusted phone number (not a phone number in an email you just received):
            </p>

            <div className="p-4 bg-slate-100 border border-slate-300 rounded-lg font-mono text-xs space-y-1">
              <p><strong>VERITITLE OFFICIAL SETTLEMENT ESCROW DESK:</strong></p>
              <p>Official Telephone: <strong>(512) 890-4100</strong></p>
              <p>Escrow Officer: <strong>Katherine Reed</strong></p>
              <p>Authorized Trust Account: <strong>VeriTitle Settlement Trust Account · JPMorgan Chase Bank</strong></p>
            </div>

            <p className="text-xs text-slate-600">
              I acknowledge receipt of this Wire Fraud Advisory and agree to independently verify all wire instructions by voice telephone call before initiating any wire transfer.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-8 pt-8 border-t border-slate-200">
            <div className="border-t border-slate-400 pt-2 text-center text-xs">
              <span className="font-semibold block">{buyer}</span>
              <span className="text-[10px] text-slate-500 uppercase">Buyer / Borrower Signature</span>
            </div>
            <div className="border-t border-slate-400 pt-2 text-center text-xs">
              <span className="font-semibold block">{seller}</span>
              <span className="text-[10px] text-slate-500 uppercase">Seller Signature</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
