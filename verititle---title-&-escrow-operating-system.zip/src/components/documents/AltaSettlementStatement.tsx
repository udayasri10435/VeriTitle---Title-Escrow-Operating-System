import React, { useState } from 'react';
import { 
  Plus, 
  Trash2, 
  Edit3, 
  Printer, 
  Download, 
  CheckCircle, 
  Info,
  DollarSign,
  AlertCircle
} from 'lucide-react';
import { Order, SettlementLineItem } from '../../types/titleEscrow';
import { formatCurrency, formatNumber, recalculateAltaStatement } from '../../utils/formatters';

interface AltaSettlementStatementProps {
  order: Order;
  onUpdateOrder: (updatedOrder: Order) => void;
}

export const AltaSettlementStatement: React.FC<AltaSettlementStatementProps> = ({
  order,
  onUpdateOrder,
}) => {
  const [statementView, setStatementView] = useState<'Combined' | 'Borrower' | 'Seller'>('Combined');
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingItem, setEditingItem] = useState<SettlementLineItem | null>(null);

  // Form states for Add / Edit
  const [section, setSection] = useState<SettlementLineItem['section']>('500_TitleCharges');
  const [lineCode, setLineCode] = useState('');
  const [description, setDescription] = useState('');
  const [payeeOrPayor, setPayeeOrPayor] = useState('');
  const [borrowerDebit, setBorrowerDebit] = useState<string>('');
  const [borrowerCredit, setBorrowerCredit] = useState<string>('');
  const [sellerDebit, setSellerDebit] = useState<string>('');
  const [sellerCredit, setSellerCredit] = useState<string>('');

  const alta = order.altaStatement;

  const sectionsConfig: { key: SettlementLineItem['section']; title: string; range: string }[] = [
    { key: '100_Financial', title: '100. Financial', range: 'Lines 101 - 199' },
    { key: '200_Prorations', title: '200. Prorations / Adjustments', range: 'Lines 201 - 299' },
    { key: '500_TitleCharges', title: '500. Title Charges & Escrow Fees', range: 'Lines 501 - 599' },
    { key: '600_GovernmentCharges', title: '600. Government Recording & Transfer Charges', range: 'Lines 601 - 699' },
    { key: '700_Payoffs', title: '700. Payoffs & Reductions', range: 'Lines 701 - 799' },
    { key: '800_Miscellaneous', title: '800. Miscellaneous / Broker Commissions', range: 'Lines 801 - 899' },
  ];

  // Open add modal
  const handleOpenAdd = (sec?: SettlementLineItem['section']) => {
    setEditingItem(null);
    setSection(sec || '500_TitleCharges');
    setLineCode('');
    setDescription('');
    setPayeeOrPayor('');
    setBorrowerDebit('');
    setBorrowerCredit('');
    setSellerDebit('');
    setSellerCredit('');
    setShowAddModal(true);
  };

  // Open edit modal
  const handleOpenEdit = (item: SettlementLineItem) => {
    setEditingItem(item);
    setSection(item.section);
    setLineCode(item.lineCode);
    setDescription(item.description);
    setPayeeOrPayor(item.payeeOrPayor);
    setBorrowerDebit(item.borrowerDebit ? String(item.borrowerDebit) : '');
    setBorrowerCredit(item.borrowerCredit ? String(item.borrowerCredit) : '');
    setSellerDebit(item.sellerDebit ? String(item.sellerDebit) : '');
    setSellerCredit(item.sellerCredit ? String(item.sellerCredit) : '');
    setShowAddModal(true);
  };

  // Delete line item
  const handleDeleteItem = (itemId: string) => {
    const updatedItems = alta.lineItems.filter((i) => i.id !== itemId);
    const updatedStatement = recalculateAltaStatement({
      ...alta,
      lineItems: updatedItems,
    });
    onUpdateOrder({
      ...order,
      altaStatement: updatedStatement,
    });
  };

  // Save (Add or Update)
  const handleSaveLineItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!description.trim()) return;

    const bDeb = borrowerDebit ? parseFloat(borrowerDebit) : undefined;
    const bCred = borrowerCredit ? parseFloat(borrowerCredit) : undefined;
    const sDeb = sellerDebit ? parseFloat(sellerDebit) : undefined;
    const sCred = sellerCredit ? parseFloat(sellerCredit) : undefined;

    let updatedItems: SettlementLineItem[];

    if (editingItem) {
      updatedItems = alta.lineItems.map((item) => {
        if (item.id === editingItem.id) {
          return {
            ...item,
            section,
            lineCode: lineCode || item.lineCode,
            description,
            payeeOrPayor: payeeOrPayor || '—',
            borrowerDebit: bDeb,
            borrowerCredit: bCred,
            sellerDebit: sDeb,
            sellerCredit: sCred,
          };
        }
        return item;
      });
    } else {
      const newItem: SettlementLineItem = {
        id: `li-${Date.now()}`,
        section,
        lineCode: lineCode || `${section.split('_')[0].substring(0, 1)}0${alta.lineItems.length + 1}`,
        description,
        payeeOrPayor: payeeOrPayor || '—',
        borrowerDebit: bDeb,
        borrowerCredit: bCred,
        sellerDebit: sDeb,
        sellerCredit: sCred,
      };
      updatedItems = [...alta.lineItems, newItem];
    }

    const updatedStatement = recalculateAltaStatement({
      ...alta,
      lineItems: updatedItems,
    });

    onUpdateOrder({
      ...order,
      altaStatement: updatedStatement,
    });

    setShowAddModal(false);
  };

  const buyer = order.parties.find((p) => p.role === 'Buyer' || p.role === 'Borrower')?.name || 'Buyer / Borrower';
  const seller = order.parties.find((p) => p.role === 'Seller')?.name || 'Seller';
  const escrowOfficer = order.parties.find((p) => p.role === 'Settlement Officer')?.name || 'Katherine Reed';

  return (
    <div className="space-y-6">
      {/* Control Strip */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4 no-print">
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Statement Format:</span>
          <div className="flex bg-slate-100 p-0.5 rounded-lg border border-slate-200">
            {(['Combined', 'Borrower', 'Seller'] as const).map((view) => (
              <button
                key={view}
                onClick={() => setStatementView(view)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                  statementView === view ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {view} ALTA
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => handleOpenAdd()}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Line Item</span>
          </button>

          <button
            onClick={() => window.print()}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-lg transition-colors"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print / PDF</span>
          </button>
        </div>
      </div>

      {/* ALTA Settlement Statement Printable Sheet */}
      <div className="bg-white border border-slate-300 rounded-xl shadow-md p-6 sm:p-10 font-sans print-sheet max-w-5xl mx-auto">
        {/* ALTA Formal Header */}
        <div className="border-b-2 border-slate-900 pb-4 mb-6">
          <div className="flex items-start justify-between">
            <div>
              <h1 className="text-xl font-bold tracking-tight text-slate-900 uppercase">
                ALTA {statementView !== 'Combined' ? statementView : 'Combined'} Settlement Statement
              </h1>
              <p className="text-xs text-slate-600 font-medium mt-0.5">
                American Land Title Association Standard Form (Adopted 05-01-2015)
              </p>
            </div>
            <div className="text-right">
              <span className="text-xs font-mono font-bold text-slate-900 block">File #: {order.fileNumber}</span>
              <span className="text-xs text-slate-500">Underwriter: {order.underwriter.split(' ')[0]}</span>
            </div>
          </div>

          {/* Metadata Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4 pt-3 border-t border-slate-200 text-xs">
            <div>
              <span className="text-slate-500 font-semibold block">Property Address:</span>
              <span className="text-slate-900 font-medium block">{order.property.address}</span>
              <span className="text-slate-600">{order.property.city}, {order.property.state} {order.property.zip}</span>
            </div>
            <div>
              <span className="text-slate-500 font-semibold block">Buyer / Borrower:</span>
              <span className="text-slate-900 font-medium block">{buyer}</span>
            </div>
            <div>
              <span className="text-slate-500 font-semibold block">Seller:</span>
              <span className="text-slate-900 font-medium block">{seller}</span>
            </div>
            <div>
              <span className="text-slate-500 font-semibold block">Settlement & Disbursement:</span>
              <span className="text-slate-900 font-mono font-medium block">Date: {alta.settlementDate}</span>
              <span className="text-slate-600">Officer: {escrowOfficer}</span>
            </div>
          </div>
        </div>

        {/* ALTA Statement Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-xs border-collapse">
            <thead>
              <tr className="bg-slate-900 text-white font-semibold">
                <th className="py-2.5 px-3 text-left w-12">Line</th>
                <th className="py-2.5 px-3 text-left">Description</th>
                <th className="py-2.5 px-3 text-left">Payee / Payor</th>
                {(statementView === 'Combined' || statementView === 'Borrower') && (
                  <>
                    <th className="py-2.5 px-3 text-right bg-slate-800 w-24">Borrower Debit</th>
                    <th className="py-2.5 px-3 text-right bg-slate-800 w-24">Borrower Credit</th>
                  </>
                )}
                {(statementView === 'Combined' || statementView === 'Seller') && (
                  <>
                    <th className="py-2.5 px-3 text-right bg-slate-850 w-24">Seller Debit</th>
                    <th className="py-2.5 px-3 text-right bg-slate-850 w-24">Seller Credit</th>
                  </>
                )}
                <th className="py-2.5 px-2 text-center w-16 no-print">Edit</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {sectionsConfig.map((sec) => {
                const items = alta.lineItems.filter((i) => i.section === sec.key);
                return (
                  <React.Fragment key={sec.key}>
                    {/* Section Header Row */}
                    <tr className="bg-slate-100 border-t-2 border-slate-300 font-bold text-slate-800">
                      <td colSpan={statementView === 'Combined' ? 7 : 5} className="py-2 px-3">
                        <div className="flex items-center justify-between">
                          <span className="tracking-wide">{sec.title}</span>
                          <button
                            type="button"
                            onClick={() => handleOpenAdd(sec.key)}
                            className="no-print text-[11px] font-normal text-emerald-700 hover:text-emerald-900 flex items-center gap-1"
                          >
                            <Plus className="w-3 h-3" /> Add {sec.title.split('.')[1].trim()}
                          </button>
                        </div>
                      </td>
                    </tr>

                    {/* Section Line Items */}
                    {items.length === 0 ? (
                      <tr className="text-slate-400 italic">
                        <td colSpan={statementView === 'Combined' ? 7 : 5} className="py-2 px-4 text-center">
                          No items in this section
                        </td>
                      </tr>
                    ) : (
                      items.map((item) => (
                        <tr key={item.id} className="hover:bg-slate-50 transition-colors">
                          <td className="py-2 px-3 font-mono text-slate-500 font-medium">{item.lineCode}</td>
                          <td className="py-2 px-3 font-medium text-slate-800">{item.description}</td>
                          <td className="py-2 px-3 text-slate-600 truncate max-w-[180px]">{item.payeeOrPayor}</td>
                          
                          {/* Borrower Columns */}
                          {(statementView === 'Combined' || statementView === 'Borrower') && (
                            <>
                              <td className="py-2 px-3 text-right font-mono tabular-nums text-slate-900">
                                {item.borrowerDebit ? formatNumber(item.borrowerDebit) : ''}
                              </td>
                              <td className="py-2 px-3 text-right font-mono tabular-nums text-emerald-800">
                                {item.borrowerCredit ? formatNumber(item.borrowerCredit) : ''}
                              </td>
                            </>
                          )}

                          {/* Seller Columns */}
                          {(statementView === 'Combined' || statementView === 'Seller') && (
                            <>
                              <td className="py-2 px-3 text-right font-mono tabular-nums text-slate-900">
                                {item.sellerDebit ? formatNumber(item.sellerDebit) : ''}
                              </td>
                              <td className="py-2 px-3 text-right font-mono tabular-nums text-emerald-800">
                                {item.sellerCredit ? formatNumber(item.sellerCredit) : ''}
                              </td>
                            </>
                          )}

                          {/* Action Buttons */}
                          <td className="py-2 px-2 text-center no-print">
                            <div className="flex items-center justify-center gap-1">
                              <button
                                onClick={() => handleOpenEdit(item)}
                                className="text-slate-400 hover:text-slate-800 p-0.5"
                                title="Edit Row"
                              >
                                <Edit3 className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => handleDeleteItem(item.id)}
                                className="text-slate-300 hover:text-red-600 p-0.5"
                                title="Delete Row"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))
                    )}
                  </React.Fragment>
                );
              })}

              {/* Subtotals & Final Balance Calculation Row */}
              <tr className="bg-slate-200 border-t-2 border-slate-400 font-bold text-slate-900">
                <td colSpan={3} className="py-2.5 px-3 uppercase tracking-wider text-right">
                  Subtotals
                </td>
                {(statementView === 'Combined' || statementView === 'Borrower') && (
                  <>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums">
                      {formatCurrency(alta.borrowerTotalDebits)}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums">
                      {formatCurrency(alta.borrowerTotalCredits)}
                    </td>
                  </>
                )}
                {(statementView === 'Combined' || statementView === 'Seller') && (
                  <>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums">
                      {formatCurrency(alta.sellerTotalDebits)}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums">
                      {formatCurrency(alta.sellerTotalCredits)}
                    </td>
                  </>
                )}
                <td className="no-print"></td>
              </tr>

              {/* Final Cash To/From Row */}
              <tr className="bg-slate-900 text-white font-bold text-sm">
                <td colSpan={3} className="py-3 px-3 uppercase tracking-wider">
                  Cash to Close & Settlement Balance
                </td>
                {(statementView === 'Combined' || statementView === 'Borrower') && (
                  <td colSpan={2} className="py-3 px-3 text-right font-mono">
                    <span className="text-xs text-slate-300 block font-normal">
                      {alta.borrowerDueFromOrTo >= 0 ? 'Cash Due FROM Borrower' : 'Refund Due TO Borrower'}:
                    </span>
                    <span className="text-base text-emerald-400">
                      {formatCurrency(Math.abs(alta.borrowerDueFromOrTo))}
                    </span>
                  </td>
                )}
                {(statementView === 'Combined' || statementView === 'Seller') && (
                  <td colSpan={2} className="py-3 px-3 text-right font-mono">
                    <span className="text-xs text-slate-300 block font-normal">
                      {alta.sellerDueToOrFrom >= 0 ? 'Cash Due TO Seller' : 'Cash Due FROM Seller'}:
                    </span>
                    <span className="text-base text-emerald-400">
                      {formatCurrency(Math.abs(alta.sellerDueToOrFrom))}
                    </span>
                  </td>
                )}
                <td className="no-print"></td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* ALTA Standard Signatures Block */}
        <div className="mt-12 pt-6 border-t border-slate-300">
          <p className="text-[11px] text-slate-500 text-justify mb-8 leading-relaxed">
            I have carefully reviewed the ALTA Settlement Statement and to the best of my knowledge and belief, 
            it is a true and accurate statement of all receipts and disbursements made on my account or by me in this transaction. 
            I further certify that I have received a copy of the ALTA Settlement Statement.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-8">
            <div className="border-t border-slate-400 pt-2 text-center">
              <span className="text-xs font-semibold text-slate-900 block">{buyer}</span>
              <span className="text-[10px] text-slate-500 uppercase tracking-wider">Buyer / Borrower Signature & Date</span>
            </div>

            <div className="border-t border-slate-400 pt-2 text-center">
              <span className="text-xs font-semibold text-slate-900 block">{seller}</span>
              <span className="text-[10px] text-slate-500 uppercase tracking-wider">Seller Signature & Date</span>
            </div>

            <div className="border-t border-slate-400 pt-2 text-center">
              <span className="text-xs font-semibold text-slate-900 block">{escrowOfficer}, Escrow Officer</span>
              <span className="text-[10px] text-slate-500 uppercase tracking-wider">Settlement Agent Acknowledgment</span>
            </div>
          </div>
        </div>
      </div>

      {/* Add / Edit Line Item Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl border border-slate-200 max-w-xl w-full p-6 shadow-2xl">
            <h3 className="text-base font-bold text-slate-900 mb-1">
              {editingItem ? 'Edit ALTA Settlement Line Item' : 'Add ALTA Settlement Line Item'}
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Enter amounts in the corresponding debit and credit columns.
            </p>

            <form onSubmit={handleSaveLineItem} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-medium text-slate-700 block mb-1">ALTA Section</label>
                  <select
                    value={section}
                    onChange={(e) => setSection(e.target.value as SettlementLineItem['section'])}
                    className="w-full text-xs p-2 bg-slate-50 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-900"
                  >
                    <option value="100_Financial">100. Financial</option>
                    <option value="200_Prorations">200. Prorations / Adjustments</option>
                    <option value="500_TitleCharges">500. Title Charges & Escrow Fees</option>
                    <option value="600_GovernmentCharges">600. Government Recording / Transfer</option>
                    <option value="700_Payoffs">700. Payoffs & Reductions</option>
                    <option value="800_Miscellaneous">800. Miscellaneous / Commissions</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs font-medium text-slate-700 block mb-1">Line Number (Optional)</label>
                  <input
                    type="text"
                    placeholder="e.g. 506"
                    value={lineCode}
                    onChange={(e) => setLineCode(e.target.value)}
                    className="w-full text-xs p-2 bg-slate-50 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-900 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-medium text-slate-700 block mb-1">Item Description</label>
                <input
                  type="text"
                  placeholder="e.g. HOA Estoppel Certificate Fee"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full text-xs p-2 bg-slate-50 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-900"
                  required
                />
              </div>

              <div>
                <label className="text-xs font-medium text-slate-700 block mb-1">Payee / Payor</label>
                <input
                  type="text"
                  placeholder="e.g. Oakridge HOA Management LLC"
                  value={payeeOrPayor}
                  onChange={(e) => setPayeeOrPayor(e.target.value)}
                  className="w-full text-xs p-2 bg-slate-50 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-900"
                />
              </div>

              {/* Debit & Credit inputs */}
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-3">
                <span className="text-xs font-semibold text-slate-700 block">Financial Allocation ($)</span>
                
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] font-medium text-slate-600 block mb-1">Borrower Debit (Owed)</label>
                    <input
                      type="number"
                      step="0.01"
                      placeholder="0.00"
                      value={borrowerDebit}
                      onChange={(e) => setBorrowerDebit(e.target.value)}
                      className="w-full text-xs p-2 bg-white border border-slate-300 rounded-lg font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-medium text-slate-600 block mb-1">Borrower Credit (Paid)</label>
                    <input
                      type="number"
                      step="0.01"
                      placeholder="0.00"
                      value={borrowerCredit}
                      onChange={(e) => setBorrowerCredit(e.target.value)}
                      className="w-full text-xs p-2 bg-white border border-slate-300 rounded-lg font-mono"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] font-medium text-slate-600 block mb-1">Seller Debit (Owed)</label>
                    <input
                      type="number"
                      step="0.01"
                      placeholder="0.00"
                      value={sellerDebit}
                      onChange={(e) => setSellerDebit(e.target.value)}
                      className="w-full text-xs p-2 bg-white border border-slate-300 rounded-lg font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-medium text-slate-600 block mb-1">Seller Credit (Earned)</label>
                    <input
                      type="number"
                      step="0.01"
                      placeholder="0.00"
                      value={sellerCredit}
                      onChange={(e) => setSellerCredit(e.target.value)}
                      className="w-full text-xs p-2 bg-white border border-slate-300 rounded-lg font-mono"
                    />
                  </div>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3 py-1.5 text-xs font-medium text-slate-600 hover:text-slate-900"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg"
                >
                  Save Line Item
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
