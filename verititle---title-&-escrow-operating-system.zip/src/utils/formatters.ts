import { AltaStatement, SettlementLineItem } from '../types/titleEscrow';

export function formatCurrency(amount: number | undefined | null): string {
  if (amount === undefined || amount === null || isNaN(amount)) return '$0.00';
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount);
}

export function formatNumber(amount: number | undefined | null): string {
  if (amount === undefined || amount === null || isNaN(amount)) return '0.00';
  return new Intl.NumberFormat('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount);
}

export function formatDate(dateString: string | undefined): string {
  if (!dateString) return '—';
  try {
    const d = new Date(dateString);
    if (isNaN(d.getTime())) return dateString;
    return d.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  } catch {
    return dateString;
  }
}

/**
 * Recalculates ALTA Statement debits, credits, and cash to close.
 */
export function recalculateAltaStatement(statement: AltaStatement): AltaStatement {
  let bDebits = 0;
  let bCredits = 0;
  let sDebits = 0;
  let sCredits = 0;

  statement.lineItems.forEach((item) => {
    if (item.borrowerDebit) bDebits += item.borrowerDebit;
    if (item.borrowerCredit) bCredits += item.borrowerCredit;
    if (item.sellerDebit) sDebits += item.sellerDebit;
    if (item.sellerCredit) sCredits += item.sellerCredit;
  });

  // Borrower balance: Total Debits - Total Credits (positive = Due from Borrower)
  const borrowerDue = bDebits - bCredits;
  // Seller balance: Total Credits - Total Debits (positive = Due to Seller)
  const sellerDue = sCredits - sDebits;

  return {
    ...statement,
    borrowerTotalDebits: bDebits,
    borrowerTotalCredits: bCredits,
    borrowerDueFromOrTo: borrowerDue,
    sellerTotalDebits: sDebits,
    sellerTotalCredits: sCredits,
    sellerDueToOrFrom: sellerDue,
  };
}

/**
 * Property Tax Proration Calculator (365-day basis)
 * Calculates seller credit/debit for property taxes already paid or unpaid.
 */
export function calculateTaxProration(
  annualTaxes: number,
  closingDateStr: string,
  taxPeriodPaid: boolean = false
): {
  dailyRate: number;
  sellerDays: number;
  buyerDays: number;
  prorationAmount: number;
  sellerDebit: boolean;
} {
  const closingDate = new Date(closingDateStr);
  const startOfYear = new Date(closingDate.getFullYear(), 0, 1);
  const diffTime = Math.abs(closingDate.getTime() - startOfYear.getTime());
  const sellerDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  const buyerDays = 365 - sellerDays;
  const dailyRate = annualTaxes / 365;

  if (taxPeriodPaid) {
    // Seller prepaid for the full year, buyer reimburses seller for remaining days
    const prorationAmount = buyerDays * dailyRate;
    return {
      dailyRate,
      sellerDays,
      buyerDays,
      prorationAmount: Math.round(prorationAmount * 100) / 100,
      sellerDebit: false, // Buyer owes seller
    };
  } else {
    // Taxes are unpaid, seller gives credit to buyer for days lived in the year
    const prorationAmount = sellerDays * dailyRate;
    return {
      dailyRate,
      sellerDays,
      buyerDays,
      prorationAmount: Math.round(prorationAmount * 100) / 100,
      sellerDebit: true, // Seller owes buyer credit
    };
  }
}

/**
 * Standard Tiered Title Insurance Rate Calculator
 */
export function estimateTitlePremium(purchasePrice: number, loanAmount: number, isRefi: boolean = false) {
  let ownersRate = 0;
  let lendersRate = 0;

  if (!isRefi) {
    // Owner's Policy Rate Tier
    if (purchasePrice <= 100000) {
      ownersRate = purchasePrice * 0.00575;
    } else if (purchasePrice <= 500000) {
      ownersRate = 575 + (purchasePrice - 100000) * 0.0045;
    } else if (purchasePrice <= 1000000) {
      ownersRate = 2375 + (purchasePrice - 500000) * 0.0035;
    } else {
      ownersRate = 4125 + (purchasePrice - 1000000) * 0.0025;
    }

    // Simultaneous Issue Loan Policy (discounted when issued with Owner's)
    lendersRate = loanAmount > 0 ? 325 : 0;
  } else {
    // Refinance Rate (Loan policy only)
    if (loanAmount <= 100000) {
      lendersRate = loanAmount * 0.00425;
    } else if (loanAmount <= 500000) {
      lendersRate = 425 + (loanAmount - 100000) * 0.0032;
    } else {
      lendersRate = 1705 + (loanAmount - 500000) * 0.0024;
    }
  }

  const settlementClosingFee = isRefi ? 450 : 650;
  const titleSearchFee = 250;
  const courierAndWireFee = 90;

  return {
    ownersPremium: Math.round(ownersRate),
    lendersPremium: Math.round(lendersRate),
    settlementClosingFee,
    titleSearchFee,
    courierAndWireFee,
    totalTitleCharges: Math.round(ownersRate + lendersRate + settlementClosingFee + titleSearchFee + courierAndWireFee),
  };
}
